<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('header');
		$this->load->model('Md');
		$records=$this->Md->getPosts();
		$data['records']=$records;
		$this->load->view('customer/home',$data);
		$this->load->view('footer');
	}
	public function create(){
		$this->load->view('header');
		$this->load->view('customer/create');
	}
	public function save(){
		   $this->form_validation->set_rules('CustomerName', 'Customer Name','required');
		   $this->form_validation->set_rules('phone', 'Phone','required');
		   $this->form_validation->set_rules('Address', 'Address','required');
		   $this->form_validation->set_rules('city', 'City','required');
		   $this->form_validation->set_rules('country', 'Country','required');

		   $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

                if ($this->form_validation->run())
                { 
                	
                	$data=array(  
                        'CustomerName'=> $this->input->post('CustomerName'),  
                        'phone'  => $this->input->post('phone'),  
                        'Address'   => $this->input->post('Address'),  
                        'city' => $this->input->post('city'), 
                        'country'=>$this->input->post('country')
                        );
                	 $this->load->model('Md'); 
                      if ($this->Md->saveRecords( $data) ) {
	                 $this->session->set_flashdata('msg', 'Records saved sucessfull');
                         } else {
	                 $this->session->set_flashdata('msg', 'Records Failed to save');

                        }
                        redirect('/');

                }
                else
                {
                	$this->load->view('header');
		            $this->load->view('customer/create');
                }
        }


        public function edit($records_id){
        $this->load->view('header');
        $this->load->model('Md');
		$record=$this->Md->getsinglePosts($records_id);
		$data['record']=$record;
        
        $this->load->view('customer/edit',$data);


        }

        public function update($records_id){
            // echo "<pre>";
            // print_r($_POST);
            // echo "</pre>";
            //die;
            // $this->form_validation->set_rules('CustomerName', 'Customer Name','required');
            // $this->form_validation->set_rules('phone', 'Phone','required');
            // $this->form_validation->set_rules('Address', 'Address','required');
            // $this->form_validation->set_rules('city', 'City','required');
            // $this->form_validation->set_rules('country', 'Country','required');
            // $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
            // if ($this->form_validation->run())
            // {
                $data=array(  
                    'CustomerName'=> $this->input->post('customername'),  
                    'phone'       => $this->input->post('phone'),  
                    'Address'     => $this->input->post('address'),  
                    'city'        => $this->input->post('city'), 
                    'country'     =>$this->input->post('country')
                    );
            	// echo "<pre>";
             //    print_r($data);
             //    echo "</pre>";
             //    die;
                $this->load->model('Md'); 
            	 if ($this->Md->update_records($records_id,$data) ) {
                 $this->session->set_flashdata('msg', 'Records update  saved sucessfull');
                     } else {
                 $this->session->set_flashdata('msg', 'Records Failed ');

                    }

            //}
            redirect('crud/edit/'.$records_id);

        }
        public function delete($records_id){
        	 $this->load->model('Md'); 
        	 if ($this->Md->deleteRecords($records_id) ) {
        	 	  $this->session->set_flashdata('msg', 'Records delete  sucessfull');

        	 }else{
        	     $this->session->set_flashdata('msg', 'Records Failed to delete');

        	 }
        	 redirect('/');


        }

	
}

