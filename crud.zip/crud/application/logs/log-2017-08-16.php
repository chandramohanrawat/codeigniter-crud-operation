<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-16 16:55:53 --> Config Class Initialized
INFO - 2017-08-16 16:55:53 --> Hooks Class Initialized
DEBUG - 2017-08-16 16:55:53 --> UTF-8 Support Enabled
INFO - 2017-08-16 16:55:53 --> Utf8 Class Initialized
INFO - 2017-08-16 16:55:53 --> URI Class Initialized
INFO - 2017-08-16 16:55:53 --> Router Class Initialized
INFO - 2017-08-16 16:55:53 --> Output Class Initialized
INFO - 2017-08-16 16:55:53 --> Security Class Initialized
DEBUG - 2017-08-16 16:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 16:55:53 --> Input Class Initialized
INFO - 2017-08-16 16:55:53 --> Language Class Initialized
INFO - 2017-08-16 16:55:53 --> Loader Class Initialized
INFO - 2017-08-16 16:55:53 --> Helper loaded: url_helper
INFO - 2017-08-16 16:55:53 --> Helper loaded: form_helper
INFO - 2017-08-16 16:55:53 --> Database Driver Class Initialized
DEBUG - 2017-08-16 16:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 16:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 16:55:54 --> Form Validation Class Initialized
INFO - 2017-08-16 16:55:54 --> Controller Class Initialized
INFO - 2017-08-16 16:55:54 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 16:55:54 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\crud\application\models\md.php 30
INFO - 2017-08-16 16:55:59 --> Config Class Initialized
INFO - 2017-08-16 16:55:59 --> Hooks Class Initialized
DEBUG - 2017-08-16 16:55:59 --> UTF-8 Support Enabled
INFO - 2017-08-16 16:55:59 --> Utf8 Class Initialized
INFO - 2017-08-16 16:55:59 --> URI Class Initialized
INFO - 2017-08-16 16:55:59 --> Router Class Initialized
INFO - 2017-08-16 16:55:59 --> Output Class Initialized
INFO - 2017-08-16 16:55:59 --> Security Class Initialized
DEBUG - 2017-08-16 16:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 16:55:59 --> Input Class Initialized
INFO - 2017-08-16 16:55:59 --> Language Class Initialized
INFO - 2017-08-16 16:55:59 --> Loader Class Initialized
INFO - 2017-08-16 16:55:59 --> Helper loaded: url_helper
INFO - 2017-08-16 16:55:59 --> Helper loaded: form_helper
INFO - 2017-08-16 16:55:59 --> Database Driver Class Initialized
DEBUG - 2017-08-16 16:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 16:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 16:55:59 --> Form Validation Class Initialized
INFO - 2017-08-16 16:55:59 --> Controller Class Initialized
INFO - 2017-08-16 16:55:59 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 16:55:59 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\crud\application\models\md.php 30
INFO - 2017-08-16 16:56:00 --> Config Class Initialized
INFO - 2017-08-16 16:56:00 --> Hooks Class Initialized
DEBUG - 2017-08-16 16:56:00 --> UTF-8 Support Enabled
INFO - 2017-08-16 16:56:00 --> Utf8 Class Initialized
INFO - 2017-08-16 16:56:00 --> URI Class Initialized
INFO - 2017-08-16 16:56:00 --> Router Class Initialized
INFO - 2017-08-16 16:56:00 --> Output Class Initialized
INFO - 2017-08-16 16:56:00 --> Security Class Initialized
DEBUG - 2017-08-16 16:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 16:56:00 --> Input Class Initialized
INFO - 2017-08-16 16:56:00 --> Language Class Initialized
INFO - 2017-08-16 16:56:01 --> Loader Class Initialized
INFO - 2017-08-16 16:56:01 --> Helper loaded: url_helper
INFO - 2017-08-16 16:56:01 --> Helper loaded: form_helper
INFO - 2017-08-16 16:56:01 --> Database Driver Class Initialized
DEBUG - 2017-08-16 16:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 16:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 16:56:01 --> Form Validation Class Initialized
INFO - 2017-08-16 16:56:01 --> Controller Class Initialized
INFO - 2017-08-16 16:56:01 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 16:56:01 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\crud\application\models\md.php 30
INFO - 2017-08-16 16:56:09 --> Config Class Initialized
INFO - 2017-08-16 16:56:09 --> Hooks Class Initialized
DEBUG - 2017-08-16 16:56:09 --> UTF-8 Support Enabled
INFO - 2017-08-16 16:56:09 --> Utf8 Class Initialized
INFO - 2017-08-16 16:56:09 --> URI Class Initialized
INFO - 2017-08-16 16:56:09 --> Router Class Initialized
INFO - 2017-08-16 16:56:09 --> Output Class Initialized
INFO - 2017-08-16 16:56:09 --> Security Class Initialized
DEBUG - 2017-08-16 16:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 16:56:09 --> Input Class Initialized
INFO - 2017-08-16 16:56:09 --> Language Class Initialized
INFO - 2017-08-16 16:56:09 --> Loader Class Initialized
INFO - 2017-08-16 16:56:09 --> Helper loaded: url_helper
INFO - 2017-08-16 16:56:09 --> Helper loaded: form_helper
INFO - 2017-08-16 16:56:09 --> Database Driver Class Initialized
DEBUG - 2017-08-16 16:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 16:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 16:56:09 --> Form Validation Class Initialized
INFO - 2017-08-16 16:56:09 --> Controller Class Initialized
INFO - 2017-08-16 16:56:09 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 16:56:09 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\crud\application\models\md.php 30
INFO - 2017-08-16 16:56:13 --> Config Class Initialized
INFO - 2017-08-16 16:56:13 --> Hooks Class Initialized
DEBUG - 2017-08-16 16:56:13 --> UTF-8 Support Enabled
INFO - 2017-08-16 16:56:13 --> Utf8 Class Initialized
INFO - 2017-08-16 16:56:13 --> URI Class Initialized
INFO - 2017-08-16 16:56:13 --> Router Class Initialized
INFO - 2017-08-16 16:56:13 --> Output Class Initialized
INFO - 2017-08-16 16:56:13 --> Security Class Initialized
DEBUG - 2017-08-16 16:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 16:56:13 --> Input Class Initialized
INFO - 2017-08-16 16:56:13 --> Language Class Initialized
INFO - 2017-08-16 16:56:13 --> Loader Class Initialized
INFO - 2017-08-16 16:56:13 --> Helper loaded: url_helper
INFO - 2017-08-16 16:56:13 --> Helper loaded: form_helper
INFO - 2017-08-16 16:56:13 --> Database Driver Class Initialized
DEBUG - 2017-08-16 16:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 16:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 16:56:13 --> Form Validation Class Initialized
INFO - 2017-08-16 16:56:13 --> Controller Class Initialized
INFO - 2017-08-16 16:56:13 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 16:56:13 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\crud\application\models\md.php 30
INFO - 2017-08-16 16:56:17 --> Config Class Initialized
INFO - 2017-08-16 16:56:17 --> Hooks Class Initialized
DEBUG - 2017-08-16 16:56:17 --> UTF-8 Support Enabled
INFO - 2017-08-16 16:56:17 --> Utf8 Class Initialized
INFO - 2017-08-16 16:56:17 --> URI Class Initialized
DEBUG - 2017-08-16 16:56:17 --> No URI present. Default controller set.
INFO - 2017-08-16 16:56:17 --> Router Class Initialized
INFO - 2017-08-16 16:56:17 --> Output Class Initialized
INFO - 2017-08-16 16:56:17 --> Security Class Initialized
DEBUG - 2017-08-16 16:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 16:56:17 --> Input Class Initialized
INFO - 2017-08-16 16:56:17 --> Language Class Initialized
INFO - 2017-08-16 16:56:17 --> Loader Class Initialized
INFO - 2017-08-16 16:56:17 --> Helper loaded: url_helper
INFO - 2017-08-16 16:56:17 --> Helper loaded: form_helper
INFO - 2017-08-16 16:56:17 --> Database Driver Class Initialized
DEBUG - 2017-08-16 16:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 16:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 16:56:17 --> Form Validation Class Initialized
INFO - 2017-08-16 16:56:17 --> Controller Class Initialized
INFO - 2017-08-16 16:56:17 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 16:56:17 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\crud\application\models\md.php 30
INFO - 2017-08-16 16:56:22 --> Config Class Initialized
INFO - 2017-08-16 16:56:22 --> Hooks Class Initialized
DEBUG - 2017-08-16 16:56:22 --> UTF-8 Support Enabled
INFO - 2017-08-16 16:56:22 --> Utf8 Class Initialized
INFO - 2017-08-16 16:56:22 --> URI Class Initialized
INFO - 2017-08-16 16:56:22 --> Router Class Initialized
INFO - 2017-08-16 16:56:22 --> Output Class Initialized
INFO - 2017-08-16 16:56:22 --> Security Class Initialized
DEBUG - 2017-08-16 16:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 16:56:22 --> Input Class Initialized
INFO - 2017-08-16 16:56:22 --> Language Class Initialized
INFO - 2017-08-16 16:56:22 --> Loader Class Initialized
INFO - 2017-08-16 16:56:22 --> Helper loaded: url_helper
INFO - 2017-08-16 16:56:22 --> Helper loaded: form_helper
INFO - 2017-08-16 16:56:22 --> Database Driver Class Initialized
DEBUG - 2017-08-16 16:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 16:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 16:56:22 --> Form Validation Class Initialized
INFO - 2017-08-16 16:56:22 --> Controller Class Initialized
INFO - 2017-08-16 16:56:22 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 16:56:22 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\crud\application\models\md.php 30
INFO - 2017-08-16 16:58:29 --> Config Class Initialized
INFO - 2017-08-16 16:58:29 --> Hooks Class Initialized
DEBUG - 2017-08-16 16:58:29 --> UTF-8 Support Enabled
INFO - 2017-08-16 16:58:29 --> Utf8 Class Initialized
INFO - 2017-08-16 16:58:29 --> URI Class Initialized
INFO - 2017-08-16 16:58:29 --> Router Class Initialized
INFO - 2017-08-16 16:58:29 --> Output Class Initialized
INFO - 2017-08-16 16:58:29 --> Security Class Initialized
DEBUG - 2017-08-16 16:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 16:58:29 --> Input Class Initialized
INFO - 2017-08-16 16:58:29 --> Language Class Initialized
INFO - 2017-08-16 16:58:29 --> Loader Class Initialized
INFO - 2017-08-16 16:58:29 --> Helper loaded: url_helper
INFO - 2017-08-16 16:58:29 --> Helper loaded: form_helper
INFO - 2017-08-16 16:58:29 --> Database Driver Class Initialized
DEBUG - 2017-08-16 16:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 16:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 16:58:29 --> Form Validation Class Initialized
INFO - 2017-08-16 16:58:29 --> Controller Class Initialized
INFO - 2017-08-16 16:58:29 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 16:58:29 --> Model Class Initialized
INFO - 2017-08-16 16:58:29 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 16:58:29 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 16:58:29 --> Final output sent to browser
DEBUG - 2017-08-16 16:58:29 --> Total execution time: 0.2588
INFO - 2017-08-16 16:58:32 --> Config Class Initialized
INFO - 2017-08-16 16:58:32 --> Hooks Class Initialized
DEBUG - 2017-08-16 16:58:32 --> UTF-8 Support Enabled
INFO - 2017-08-16 16:58:32 --> Utf8 Class Initialized
INFO - 2017-08-16 16:58:32 --> URI Class Initialized
INFO - 2017-08-16 16:58:32 --> Router Class Initialized
INFO - 2017-08-16 16:58:32 --> Output Class Initialized
INFO - 2017-08-16 16:58:32 --> Security Class Initialized
DEBUG - 2017-08-16 16:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 16:58:32 --> Input Class Initialized
INFO - 2017-08-16 16:58:32 --> Language Class Initialized
INFO - 2017-08-16 16:58:32 --> Loader Class Initialized
INFO - 2017-08-16 16:58:32 --> Helper loaded: url_helper
INFO - 2017-08-16 16:58:32 --> Helper loaded: form_helper
INFO - 2017-08-16 16:58:32 --> Database Driver Class Initialized
DEBUG - 2017-08-16 16:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 16:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 16:58:32 --> Form Validation Class Initialized
INFO - 2017-08-16 16:58:32 --> Controller Class Initialized
INFO - 2017-08-16 16:58:32 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 16:58:32 --> Model Class Initialized
INFO - 2017-08-16 16:58:32 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 16:58:32 --> Final output sent to browser
DEBUG - 2017-08-16 16:58:32 --> Total execution time: 0.2160
INFO - 2017-08-16 16:58:38 --> Config Class Initialized
INFO - 2017-08-16 16:58:38 --> Hooks Class Initialized
DEBUG - 2017-08-16 16:58:38 --> UTF-8 Support Enabled
INFO - 2017-08-16 16:58:38 --> Utf8 Class Initialized
INFO - 2017-08-16 16:58:38 --> URI Class Initialized
INFO - 2017-08-16 16:58:38 --> Router Class Initialized
INFO - 2017-08-16 16:58:38 --> Output Class Initialized
INFO - 2017-08-16 16:58:38 --> Security Class Initialized
DEBUG - 2017-08-16 16:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 16:58:38 --> Input Class Initialized
INFO - 2017-08-16 16:58:38 --> Language Class Initialized
INFO - 2017-08-16 16:58:38 --> Loader Class Initialized
INFO - 2017-08-16 16:58:38 --> Helper loaded: url_helper
INFO - 2017-08-16 16:58:39 --> Helper loaded: form_helper
INFO - 2017-08-16 16:58:39 --> Database Driver Class Initialized
DEBUG - 2017-08-16 16:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 16:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 16:58:39 --> Form Validation Class Initialized
INFO - 2017-08-16 16:58:39 --> Controller Class Initialized
INFO - 2017-08-16 16:58:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 16:58:39 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 7
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 7
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 17
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 17
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 27
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 27
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 38
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 38
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 50
ERROR - 2017-08-16 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 50
INFO - 2017-08-16 16:58:39 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 16:58:39 --> Final output sent to browser
DEBUG - 2017-08-16 16:58:39 --> Total execution time: 0.3227
INFO - 2017-08-16 17:00:19 --> Config Class Initialized
INFO - 2017-08-16 17:00:19 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:00:19 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:00:19 --> Utf8 Class Initialized
INFO - 2017-08-16 17:00:19 --> URI Class Initialized
INFO - 2017-08-16 17:00:19 --> Router Class Initialized
INFO - 2017-08-16 17:00:19 --> Output Class Initialized
INFO - 2017-08-16 17:00:19 --> Security Class Initialized
DEBUG - 2017-08-16 17:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:00:19 --> Input Class Initialized
INFO - 2017-08-16 17:00:19 --> Language Class Initialized
INFO - 2017-08-16 17:00:19 --> Loader Class Initialized
INFO - 2017-08-16 17:00:19 --> Helper loaded: url_helper
INFO - 2017-08-16 17:00:19 --> Helper loaded: form_helper
INFO - 2017-08-16 17:00:19 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:00:19 --> Form Validation Class Initialized
INFO - 2017-08-16 17:00:19 --> Controller Class Initialized
INFO - 2017-08-16 17:00:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:00:19 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 7
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 7
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 17
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 17
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 27
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 27
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 38
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 38
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 50
ERROR - 2017-08-16 17:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 50
INFO - 2017-08-16 17:00:19 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:00:19 --> Final output sent to browser
DEBUG - 2017-08-16 17:00:19 --> Total execution time: 0.3322
INFO - 2017-08-16 17:02:02 --> Config Class Initialized
INFO - 2017-08-16 17:02:02 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:02:02 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:02:02 --> Utf8 Class Initialized
INFO - 2017-08-16 17:02:02 --> URI Class Initialized
INFO - 2017-08-16 17:02:02 --> Router Class Initialized
INFO - 2017-08-16 17:02:02 --> Output Class Initialized
INFO - 2017-08-16 17:02:02 --> Security Class Initialized
DEBUG - 2017-08-16 17:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:02:02 --> Input Class Initialized
INFO - 2017-08-16 17:02:02 --> Language Class Initialized
INFO - 2017-08-16 17:02:02 --> Loader Class Initialized
INFO - 2017-08-16 17:02:02 --> Helper loaded: url_helper
INFO - 2017-08-16 17:02:02 --> Helper loaded: form_helper
INFO - 2017-08-16 17:02:02 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:02:02 --> Form Validation Class Initialized
INFO - 2017-08-16 17:02:02 --> Controller Class Initialized
INFO - 2017-08-16 17:02:02 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:02:02 --> Model Class Initialized
INFO - 2017-08-16 17:02:02 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:02:02 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:02:02 --> Final output sent to browser
DEBUG - 2017-08-16 17:02:02 --> Total execution time: 0.2778
INFO - 2017-08-16 17:02:06 --> Config Class Initialized
INFO - 2017-08-16 17:02:06 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:02:06 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:02:06 --> Utf8 Class Initialized
INFO - 2017-08-16 17:02:06 --> URI Class Initialized
INFO - 2017-08-16 17:02:06 --> Router Class Initialized
INFO - 2017-08-16 17:02:06 --> Output Class Initialized
INFO - 2017-08-16 17:02:06 --> Security Class Initialized
DEBUG - 2017-08-16 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:02:06 --> Input Class Initialized
INFO - 2017-08-16 17:02:06 --> Language Class Initialized
INFO - 2017-08-16 17:02:06 --> Loader Class Initialized
INFO - 2017-08-16 17:02:06 --> Helper loaded: url_helper
INFO - 2017-08-16 17:02:06 --> Helper loaded: form_helper
INFO - 2017-08-16 17:02:06 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:02:06 --> Form Validation Class Initialized
INFO - 2017-08-16 17:02:06 --> Controller Class Initialized
INFO - 2017-08-16 17:02:06 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:02:06 --> Model Class Initialized
INFO - 2017-08-16 17:02:06 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:02:06 --> Final output sent to browser
DEBUG - 2017-08-16 17:02:06 --> Total execution time: 0.2361
INFO - 2017-08-16 17:02:19 --> Config Class Initialized
INFO - 2017-08-16 17:02:19 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:02:19 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:02:19 --> Utf8 Class Initialized
INFO - 2017-08-16 17:02:19 --> URI Class Initialized
INFO - 2017-08-16 17:02:19 --> Router Class Initialized
INFO - 2017-08-16 17:02:19 --> Output Class Initialized
INFO - 2017-08-16 17:02:19 --> Security Class Initialized
DEBUG - 2017-08-16 17:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:02:19 --> Input Class Initialized
INFO - 2017-08-16 17:02:19 --> Language Class Initialized
INFO - 2017-08-16 17:02:19 --> Loader Class Initialized
INFO - 2017-08-16 17:02:19 --> Helper loaded: url_helper
INFO - 2017-08-16 17:02:19 --> Helper loaded: form_helper
INFO - 2017-08-16 17:02:19 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:02:19 --> Form Validation Class Initialized
INFO - 2017-08-16 17:02:19 --> Controller Class Initialized
INFO - 2017-08-16 17:02:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:02:19 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 17:02:19 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:02:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:02:19 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 4
ERROR - 2017-08-16 17:02:19 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:02:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:02:20 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:02:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:02:20 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:02:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:02:20 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:02:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:02:20 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 51
ERROR - 2017-08-16 17:02:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 51
INFO - 2017-08-16 17:02:20 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:02:20 --> Final output sent to browser
DEBUG - 2017-08-16 17:02:20 --> Total execution time: 0.3508
INFO - 2017-08-16 17:02:32 --> Config Class Initialized
INFO - 2017-08-16 17:02:32 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:02:32 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:02:32 --> Utf8 Class Initialized
INFO - 2017-08-16 17:02:32 --> URI Class Initialized
INFO - 2017-08-16 17:02:32 --> Router Class Initialized
INFO - 2017-08-16 17:02:32 --> Output Class Initialized
INFO - 2017-08-16 17:02:32 --> Security Class Initialized
DEBUG - 2017-08-16 17:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:02:32 --> Input Class Initialized
INFO - 2017-08-16 17:02:32 --> Language Class Initialized
INFO - 2017-08-16 17:02:32 --> Loader Class Initialized
INFO - 2017-08-16 17:02:32 --> Helper loaded: url_helper
INFO - 2017-08-16 17:02:32 --> Helper loaded: form_helper
INFO - 2017-08-16 17:02:32 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:02:32 --> Form Validation Class Initialized
INFO - 2017-08-16 17:02:32 --> Controller Class Initialized
INFO - 2017-08-16 17:02:32 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:02:32 --> Model Class Initialized
INFO - 2017-08-16 17:02:32 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:02:32 --> Final output sent to browser
DEBUG - 2017-08-16 17:02:32 --> Total execution time: 0.2408
INFO - 2017-08-16 17:02:34 --> Config Class Initialized
INFO - 2017-08-16 17:02:34 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:02:34 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:02:34 --> Utf8 Class Initialized
INFO - 2017-08-16 17:02:34 --> URI Class Initialized
INFO - 2017-08-16 17:02:34 --> Router Class Initialized
INFO - 2017-08-16 17:02:34 --> Output Class Initialized
INFO - 2017-08-16 17:02:34 --> Security Class Initialized
DEBUG - 2017-08-16 17:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:02:34 --> Input Class Initialized
INFO - 2017-08-16 17:02:34 --> Language Class Initialized
INFO - 2017-08-16 17:02:34 --> Loader Class Initialized
INFO - 2017-08-16 17:02:34 --> Helper loaded: url_helper
INFO - 2017-08-16 17:02:34 --> Helper loaded: form_helper
INFO - 2017-08-16 17:02:34 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:02:34 --> Form Validation Class Initialized
INFO - 2017-08-16 17:02:34 --> Controller Class Initialized
INFO - 2017-08-16 17:02:34 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:02:34 --> Model Class Initialized
INFO - 2017-08-16 17:02:34 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:02:34 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:02:34 --> Final output sent to browser
DEBUG - 2017-08-16 17:02:34 --> Total execution time: 0.2543
INFO - 2017-08-16 17:02:48 --> Config Class Initialized
INFO - 2017-08-16 17:02:48 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:02:48 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:02:48 --> Utf8 Class Initialized
INFO - 2017-08-16 17:02:48 --> URI Class Initialized
INFO - 2017-08-16 17:02:48 --> Router Class Initialized
INFO - 2017-08-16 17:02:48 --> Output Class Initialized
INFO - 2017-08-16 17:02:48 --> Security Class Initialized
DEBUG - 2017-08-16 17:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:02:48 --> Input Class Initialized
INFO - 2017-08-16 17:02:48 --> Language Class Initialized
ERROR - 2017-08-16 17:02:48 --> 404 Page Not Found: Crud/view
INFO - 2017-08-16 17:02:53 --> Config Class Initialized
INFO - 2017-08-16 17:02:53 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:02:53 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:02:53 --> Utf8 Class Initialized
INFO - 2017-08-16 17:02:53 --> URI Class Initialized
INFO - 2017-08-16 17:02:53 --> Router Class Initialized
INFO - 2017-08-16 17:02:53 --> Output Class Initialized
INFO - 2017-08-16 17:02:53 --> Security Class Initialized
DEBUG - 2017-08-16 17:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:02:53 --> Input Class Initialized
INFO - 2017-08-16 17:02:53 --> Language Class Initialized
INFO - 2017-08-16 17:02:53 --> Loader Class Initialized
INFO - 2017-08-16 17:02:53 --> Helper loaded: url_helper
INFO - 2017-08-16 17:02:53 --> Helper loaded: form_helper
INFO - 2017-08-16 17:02:53 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:02:53 --> Form Validation Class Initialized
INFO - 2017-08-16 17:02:53 --> Controller Class Initialized
INFO - 2017-08-16 17:02:53 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:02:53 --> Model Class Initialized
INFO - 2017-08-16 17:02:53 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:02:53 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:02:53 --> Final output sent to browser
DEBUG - 2017-08-16 17:02:53 --> Total execution time: 0.2525
INFO - 2017-08-16 17:02:56 --> Config Class Initialized
INFO - 2017-08-16 17:02:56 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:02:56 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:02:56 --> Utf8 Class Initialized
INFO - 2017-08-16 17:02:56 --> URI Class Initialized
INFO - 2017-08-16 17:02:56 --> Router Class Initialized
INFO - 2017-08-16 17:02:56 --> Output Class Initialized
INFO - 2017-08-16 17:02:56 --> Security Class Initialized
DEBUG - 2017-08-16 17:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:02:56 --> Input Class Initialized
INFO - 2017-08-16 17:02:56 --> Language Class Initialized
INFO - 2017-08-16 17:02:56 --> Loader Class Initialized
INFO - 2017-08-16 17:02:56 --> Helper loaded: url_helper
INFO - 2017-08-16 17:02:56 --> Helper loaded: form_helper
INFO - 2017-08-16 17:02:56 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:02:56 --> Form Validation Class Initialized
INFO - 2017-08-16 17:02:56 --> Controller Class Initialized
INFO - 2017-08-16 17:02:56 --> Model Class Initialized
INFO - 2017-08-16 17:02:56 --> Config Class Initialized
INFO - 2017-08-16 17:02:56 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:02:56 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:02:56 --> Utf8 Class Initialized
INFO - 2017-08-16 17:02:56 --> URI Class Initialized
DEBUG - 2017-08-16 17:02:56 --> No URI present. Default controller set.
INFO - 2017-08-16 17:02:56 --> Router Class Initialized
INFO - 2017-08-16 17:02:56 --> Output Class Initialized
INFO - 2017-08-16 17:02:56 --> Security Class Initialized
DEBUG - 2017-08-16 17:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:02:56 --> Input Class Initialized
INFO - 2017-08-16 17:02:56 --> Language Class Initialized
INFO - 2017-08-16 17:02:56 --> Loader Class Initialized
INFO - 2017-08-16 17:02:56 --> Helper loaded: url_helper
INFO - 2017-08-16 17:02:57 --> Helper loaded: form_helper
INFO - 2017-08-16 17:02:57 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:02:57 --> Form Validation Class Initialized
INFO - 2017-08-16 17:02:57 --> Controller Class Initialized
INFO - 2017-08-16 17:02:57 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:02:57 --> Model Class Initialized
INFO - 2017-08-16 17:02:57 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:02:57 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:02:57 --> Final output sent to browser
DEBUG - 2017-08-16 17:02:57 --> Total execution time: 0.2539
INFO - 2017-08-16 17:03:01 --> Config Class Initialized
INFO - 2017-08-16 17:03:01 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:03:01 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:03:01 --> Utf8 Class Initialized
INFO - 2017-08-16 17:03:01 --> URI Class Initialized
INFO - 2017-08-16 17:03:01 --> Router Class Initialized
INFO - 2017-08-16 17:03:01 --> Output Class Initialized
INFO - 2017-08-16 17:03:01 --> Security Class Initialized
DEBUG - 2017-08-16 17:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:03:01 --> Input Class Initialized
INFO - 2017-08-16 17:03:01 --> Language Class Initialized
INFO - 2017-08-16 17:03:01 --> Loader Class Initialized
INFO - 2017-08-16 17:03:01 --> Helper loaded: url_helper
INFO - 2017-08-16 17:03:01 --> Helper loaded: form_helper
INFO - 2017-08-16 17:03:01 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:03:01 --> Form Validation Class Initialized
INFO - 2017-08-16 17:03:01 --> Controller Class Initialized
INFO - 2017-08-16 17:03:01 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:03:01 --> Model Class Initialized
INFO - 2017-08-16 17:03:01 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:03:01 --> Final output sent to browser
DEBUG - 2017-08-16 17:03:01 --> Total execution time: 0.2770
INFO - 2017-08-16 17:03:12 --> Config Class Initialized
INFO - 2017-08-16 17:03:12 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:03:12 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:03:12 --> Utf8 Class Initialized
INFO - 2017-08-16 17:03:12 --> URI Class Initialized
INFO - 2017-08-16 17:03:12 --> Router Class Initialized
INFO - 2017-08-16 17:03:12 --> Output Class Initialized
INFO - 2017-08-16 17:03:12 --> Security Class Initialized
DEBUG - 2017-08-16 17:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:03:12 --> Input Class Initialized
INFO - 2017-08-16 17:03:12 --> Language Class Initialized
INFO - 2017-08-16 17:03:12 --> Loader Class Initialized
INFO - 2017-08-16 17:03:12 --> Helper loaded: url_helper
INFO - 2017-08-16 17:03:12 --> Helper loaded: form_helper
INFO - 2017-08-16 17:03:12 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:03:12 --> Form Validation Class Initialized
INFO - 2017-08-16 17:03:12 --> Controller Class Initialized
INFO - 2017-08-16 17:03:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:03:12 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 4
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 51
ERROR - 2017-08-16 17:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 51
INFO - 2017-08-16 17:03:12 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:03:12 --> Final output sent to browser
DEBUG - 2017-08-16 17:03:12 --> Total execution time: 0.3734
INFO - 2017-08-16 17:06:56 --> Config Class Initialized
INFO - 2017-08-16 17:06:56 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:06:56 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:06:56 --> Utf8 Class Initialized
INFO - 2017-08-16 17:06:56 --> URI Class Initialized
INFO - 2017-08-16 17:06:56 --> Router Class Initialized
INFO - 2017-08-16 17:06:56 --> Output Class Initialized
INFO - 2017-08-16 17:06:56 --> Security Class Initialized
DEBUG - 2017-08-16 17:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:06:56 --> Input Class Initialized
INFO - 2017-08-16 17:06:56 --> Language Class Initialized
INFO - 2017-08-16 17:06:56 --> Loader Class Initialized
INFO - 2017-08-16 17:06:56 --> Helper loaded: url_helper
INFO - 2017-08-16 17:06:56 --> Helper loaded: form_helper
INFO - 2017-08-16 17:06:56 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:06:56 --> Form Validation Class Initialized
INFO - 2017-08-16 17:06:56 --> Controller Class Initialized
INFO - 2017-08-16 17:06:56 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:06:56 --> Model Class Initialized
INFO - 2017-08-16 17:06:56 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:06:56 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:06:56 --> Final output sent to browser
DEBUG - 2017-08-16 17:06:56 --> Total execution time: 0.2428
INFO - 2017-08-16 17:06:59 --> Config Class Initialized
INFO - 2017-08-16 17:06:59 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:06:59 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:06:59 --> Utf8 Class Initialized
INFO - 2017-08-16 17:06:59 --> URI Class Initialized
INFO - 2017-08-16 17:06:59 --> Router Class Initialized
INFO - 2017-08-16 17:06:59 --> Output Class Initialized
INFO - 2017-08-16 17:06:59 --> Security Class Initialized
DEBUG - 2017-08-16 17:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:06:59 --> Input Class Initialized
INFO - 2017-08-16 17:06:59 --> Language Class Initialized
INFO - 2017-08-16 17:06:59 --> Loader Class Initialized
INFO - 2017-08-16 17:06:59 --> Helper loaded: url_helper
INFO - 2017-08-16 17:06:59 --> Helper loaded: form_helper
INFO - 2017-08-16 17:06:59 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:06:59 --> Form Validation Class Initialized
INFO - 2017-08-16 17:06:59 --> Controller Class Initialized
INFO - 2017-08-16 17:06:59 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:06:59 --> Model Class Initialized
INFO - 2017-08-16 17:06:59 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:06:59 --> Final output sent to browser
DEBUG - 2017-08-16 17:06:59 --> Total execution time: 0.2384
INFO - 2017-08-16 17:07:05 --> Config Class Initialized
INFO - 2017-08-16 17:07:05 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:07:05 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:07:05 --> Utf8 Class Initialized
INFO - 2017-08-16 17:07:05 --> URI Class Initialized
INFO - 2017-08-16 17:07:05 --> Router Class Initialized
INFO - 2017-08-16 17:07:05 --> Output Class Initialized
INFO - 2017-08-16 17:07:05 --> Security Class Initialized
DEBUG - 2017-08-16 17:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:07:05 --> Input Class Initialized
INFO - 2017-08-16 17:07:05 --> Language Class Initialized
INFO - 2017-08-16 17:07:05 --> Loader Class Initialized
INFO - 2017-08-16 17:07:05 --> Helper loaded: url_helper
INFO - 2017-08-16 17:07:05 --> Helper loaded: form_helper
INFO - 2017-08-16 17:07:05 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:07:05 --> Form Validation Class Initialized
INFO - 2017-08-16 17:07:05 --> Controller Class Initialized
INFO - 2017-08-16 17:07:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:07:05 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 4
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 51
ERROR - 2017-08-16 17:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 51
INFO - 2017-08-16 17:07:05 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:07:05 --> Final output sent to browser
DEBUG - 2017-08-16 17:07:05 --> Total execution time: 0.3651
INFO - 2017-08-16 17:07:25 --> Config Class Initialized
INFO - 2017-08-16 17:07:25 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:07:25 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:07:25 --> Utf8 Class Initialized
INFO - 2017-08-16 17:07:25 --> URI Class Initialized
INFO - 2017-08-16 17:07:25 --> Router Class Initialized
INFO - 2017-08-16 17:07:25 --> Output Class Initialized
INFO - 2017-08-16 17:07:25 --> Security Class Initialized
DEBUG - 2017-08-16 17:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:07:25 --> Input Class Initialized
INFO - 2017-08-16 17:07:25 --> Language Class Initialized
INFO - 2017-08-16 17:07:25 --> Loader Class Initialized
INFO - 2017-08-16 17:07:25 --> Helper loaded: url_helper
INFO - 2017-08-16 17:07:25 --> Helper loaded: form_helper
INFO - 2017-08-16 17:07:25 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:07:25 --> Form Validation Class Initialized
INFO - 2017-08-16 17:07:25 --> Controller Class Initialized
INFO - 2017-08-16 17:07:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:07:25 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 4
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 51
ERROR - 2017-08-16 17:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 51
INFO - 2017-08-16 17:07:25 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:07:25 --> Final output sent to browser
DEBUG - 2017-08-16 17:07:25 --> Total execution time: 0.3525
INFO - 2017-08-16 17:07:37 --> Config Class Initialized
INFO - 2017-08-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:07:37 --> Utf8 Class Initialized
INFO - 2017-08-16 17:07:37 --> URI Class Initialized
INFO - 2017-08-16 17:07:37 --> Router Class Initialized
INFO - 2017-08-16 17:07:37 --> Output Class Initialized
INFO - 2017-08-16 17:07:37 --> Security Class Initialized
DEBUG - 2017-08-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:07:37 --> Input Class Initialized
INFO - 2017-08-16 17:07:37 --> Language Class Initialized
INFO - 2017-08-16 17:07:37 --> Loader Class Initialized
INFO - 2017-08-16 17:07:37 --> Helper loaded: url_helper
INFO - 2017-08-16 17:07:37 --> Helper loaded: form_helper
INFO - 2017-08-16 17:07:37 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:07:37 --> Form Validation Class Initialized
INFO - 2017-08-16 17:07:37 --> Controller Class Initialized
INFO - 2017-08-16 17:07:37 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:07:37 --> Model Class Initialized
INFO - 2017-08-16 17:07:37 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:07:37 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:07:37 --> Final output sent to browser
DEBUG - 2017-08-16 17:07:37 --> Total execution time: 0.2374
INFO - 2017-08-16 17:07:40 --> Config Class Initialized
INFO - 2017-08-16 17:07:40 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:07:40 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:07:40 --> Utf8 Class Initialized
INFO - 2017-08-16 17:07:40 --> URI Class Initialized
INFO - 2017-08-16 17:07:40 --> Router Class Initialized
INFO - 2017-08-16 17:07:40 --> Output Class Initialized
INFO - 2017-08-16 17:07:40 --> Security Class Initialized
DEBUG - 2017-08-16 17:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:07:40 --> Input Class Initialized
INFO - 2017-08-16 17:07:40 --> Language Class Initialized
INFO - 2017-08-16 17:07:40 --> Loader Class Initialized
INFO - 2017-08-16 17:07:40 --> Helper loaded: url_helper
INFO - 2017-08-16 17:07:40 --> Helper loaded: form_helper
INFO - 2017-08-16 17:07:40 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:07:40 --> Form Validation Class Initialized
INFO - 2017-08-16 17:07:40 --> Controller Class Initialized
INFO - 2017-08-16 17:07:40 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:07:40 --> Model Class Initialized
INFO - 2017-08-16 17:07:40 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:07:40 --> Final output sent to browser
DEBUG - 2017-08-16 17:07:40 --> Total execution time: 0.2347
INFO - 2017-08-16 17:07:47 --> Config Class Initialized
INFO - 2017-08-16 17:07:47 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:07:47 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:07:47 --> Utf8 Class Initialized
INFO - 2017-08-16 17:07:47 --> URI Class Initialized
INFO - 2017-08-16 17:07:47 --> Router Class Initialized
INFO - 2017-08-16 17:07:47 --> Output Class Initialized
INFO - 2017-08-16 17:07:47 --> Security Class Initialized
DEBUG - 2017-08-16 17:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:07:47 --> Input Class Initialized
INFO - 2017-08-16 17:07:47 --> Language Class Initialized
INFO - 2017-08-16 17:07:47 --> Loader Class Initialized
INFO - 2017-08-16 17:07:47 --> Helper loaded: url_helper
INFO - 2017-08-16 17:07:47 --> Helper loaded: form_helper
INFO - 2017-08-16 17:07:47 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:07:47 --> Form Validation Class Initialized
INFO - 2017-08-16 17:07:47 --> Controller Class Initialized
INFO - 2017-08-16 17:07:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:07:47 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 4
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 51
ERROR - 2017-08-16 17:07:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 51
INFO - 2017-08-16 17:07:47 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:07:47 --> Final output sent to browser
DEBUG - 2017-08-16 17:07:47 --> Total execution time: 0.3747
INFO - 2017-08-16 17:17:19 --> Config Class Initialized
INFO - 2017-08-16 17:17:19 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:17:19 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:17:19 --> Utf8 Class Initialized
INFO - 2017-08-16 17:17:19 --> URI Class Initialized
INFO - 2017-08-16 17:17:19 --> Router Class Initialized
INFO - 2017-08-16 17:17:19 --> Output Class Initialized
INFO - 2017-08-16 17:17:19 --> Security Class Initialized
DEBUG - 2017-08-16 17:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:17:19 --> Input Class Initialized
INFO - 2017-08-16 17:17:19 --> Language Class Initialized
INFO - 2017-08-16 17:17:19 --> Loader Class Initialized
INFO - 2017-08-16 17:17:19 --> Helper loaded: url_helper
INFO - 2017-08-16 17:17:19 --> Helper loaded: form_helper
INFO - 2017-08-16 17:17:19 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:17:19 --> Form Validation Class Initialized
INFO - 2017-08-16 17:17:19 --> Controller Class Initialized
INFO - 2017-08-16 17:17:19 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:17:19 --> Model Class Initialized
INFO - 2017-08-16 17:17:19 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:17:19 --> Final output sent to browser
DEBUG - 2017-08-16 17:17:19 --> Total execution time: 0.2480
INFO - 2017-08-16 17:17:24 --> Config Class Initialized
INFO - 2017-08-16 17:17:24 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:17:24 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:17:24 --> Utf8 Class Initialized
INFO - 2017-08-16 17:17:24 --> URI Class Initialized
INFO - 2017-08-16 17:17:24 --> Router Class Initialized
INFO - 2017-08-16 17:17:24 --> Output Class Initialized
INFO - 2017-08-16 17:17:24 --> Security Class Initialized
DEBUG - 2017-08-16 17:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:17:24 --> Input Class Initialized
INFO - 2017-08-16 17:17:24 --> Language Class Initialized
INFO - 2017-08-16 17:17:24 --> Loader Class Initialized
INFO - 2017-08-16 17:17:24 --> Helper loaded: url_helper
INFO - 2017-08-16 17:17:24 --> Helper loaded: form_helper
INFO - 2017-08-16 17:17:24 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:17:24 --> Form Validation Class Initialized
INFO - 2017-08-16 17:17:24 --> Controller Class Initialized
INFO - 2017-08-16 17:17:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:17:24 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 4
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 51
ERROR - 2017-08-16 17:17:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 51
INFO - 2017-08-16 17:17:24 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:17:24 --> Final output sent to browser
DEBUG - 2017-08-16 17:17:24 --> Total execution time: 0.3795
INFO - 2017-08-16 17:20:02 --> Config Class Initialized
INFO - 2017-08-16 17:20:02 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:20:02 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:20:02 --> Utf8 Class Initialized
INFO - 2017-08-16 17:20:02 --> URI Class Initialized
INFO - 2017-08-16 17:20:02 --> Router Class Initialized
INFO - 2017-08-16 17:20:02 --> Output Class Initialized
INFO - 2017-08-16 17:20:02 --> Security Class Initialized
DEBUG - 2017-08-16 17:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:20:02 --> Input Class Initialized
INFO - 2017-08-16 17:20:02 --> Language Class Initialized
INFO - 2017-08-16 17:20:02 --> Loader Class Initialized
INFO - 2017-08-16 17:20:02 --> Helper loaded: url_helper
INFO - 2017-08-16 17:20:02 --> Helper loaded: form_helper
INFO - 2017-08-16 17:20:02 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:20:02 --> Form Validation Class Initialized
INFO - 2017-08-16 17:20:02 --> Controller Class Initialized
INFO - 2017-08-16 17:20:02 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:20:02 --> Model Class Initialized
INFO - 2017-08-16 17:20:02 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:20:02 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:20:02 --> Final output sent to browser
DEBUG - 2017-08-16 17:20:03 --> Total execution time: 0.3166
INFO - 2017-08-16 17:20:06 --> Config Class Initialized
INFO - 2017-08-16 17:20:06 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:20:06 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:20:06 --> Utf8 Class Initialized
INFO - 2017-08-16 17:20:06 --> URI Class Initialized
INFO - 2017-08-16 17:20:06 --> Router Class Initialized
INFO - 2017-08-16 17:20:06 --> Output Class Initialized
INFO - 2017-08-16 17:20:06 --> Security Class Initialized
DEBUG - 2017-08-16 17:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:20:06 --> Input Class Initialized
INFO - 2017-08-16 17:20:06 --> Language Class Initialized
INFO - 2017-08-16 17:20:06 --> Loader Class Initialized
INFO - 2017-08-16 17:20:06 --> Helper loaded: url_helper
INFO - 2017-08-16 17:20:06 --> Helper loaded: form_helper
INFO - 2017-08-16 17:20:06 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:20:06 --> Form Validation Class Initialized
INFO - 2017-08-16 17:20:06 --> Controller Class Initialized
INFO - 2017-08-16 17:20:06 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:20:06 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/create.php
INFO - 2017-08-16 17:20:06 --> Final output sent to browser
DEBUG - 2017-08-16 17:20:06 --> Total execution time: 0.2497
INFO - 2017-08-16 17:20:16 --> Config Class Initialized
INFO - 2017-08-16 17:20:16 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:20:16 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:20:16 --> Utf8 Class Initialized
INFO - 2017-08-16 17:20:16 --> URI Class Initialized
INFO - 2017-08-16 17:20:16 --> Router Class Initialized
INFO - 2017-08-16 17:20:16 --> Output Class Initialized
INFO - 2017-08-16 17:20:16 --> Security Class Initialized
DEBUG - 2017-08-16 17:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:20:16 --> Input Class Initialized
INFO - 2017-08-16 17:20:16 --> Language Class Initialized
INFO - 2017-08-16 17:20:16 --> Loader Class Initialized
INFO - 2017-08-16 17:20:17 --> Helper loaded: url_helper
INFO - 2017-08-16 17:20:17 --> Helper loaded: form_helper
INFO - 2017-08-16 17:20:17 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:20:17 --> Form Validation Class Initialized
INFO - 2017-08-16 17:20:17 --> Controller Class Initialized
INFO - 2017-08-16 17:20:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:20:17 --> Model Class Initialized
INFO - 2017-08-16 17:20:17 --> Config Class Initialized
INFO - 2017-08-16 17:20:17 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:20:17 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:20:17 --> Utf8 Class Initialized
INFO - 2017-08-16 17:20:17 --> URI Class Initialized
DEBUG - 2017-08-16 17:20:17 --> No URI present. Default controller set.
INFO - 2017-08-16 17:20:17 --> Router Class Initialized
INFO - 2017-08-16 17:20:17 --> Output Class Initialized
INFO - 2017-08-16 17:20:17 --> Security Class Initialized
DEBUG - 2017-08-16 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:20:17 --> Input Class Initialized
INFO - 2017-08-16 17:20:17 --> Language Class Initialized
INFO - 2017-08-16 17:20:17 --> Loader Class Initialized
INFO - 2017-08-16 17:20:17 --> Helper loaded: url_helper
INFO - 2017-08-16 17:20:17 --> Helper loaded: form_helper
INFO - 2017-08-16 17:20:17 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:20:17 --> Form Validation Class Initialized
INFO - 2017-08-16 17:20:17 --> Controller Class Initialized
INFO - 2017-08-16 17:20:17 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:20:17 --> Model Class Initialized
INFO - 2017-08-16 17:20:17 --> Config Class Initialized
INFO - 2017-08-16 17:20:17 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:20:17 --> Hooks Class Initialized
INFO - 2017-08-16 17:20:17 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
DEBUG - 2017-08-16 17:20:17 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:20:17 --> Final output sent to browser
INFO - 2017-08-16 17:20:17 --> Utf8 Class Initialized
DEBUG - 2017-08-16 17:20:17 --> Total execution time: 0.2987
INFO - 2017-08-16 17:20:17 --> URI Class Initialized
INFO - 2017-08-16 17:20:17 --> Router Class Initialized
INFO - 2017-08-16 17:20:17 --> Output Class Initialized
INFO - 2017-08-16 17:20:17 --> Security Class Initialized
DEBUG - 2017-08-16 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:20:17 --> Input Class Initialized
INFO - 2017-08-16 17:20:17 --> Language Class Initialized
INFO - 2017-08-16 17:20:17 --> Loader Class Initialized
INFO - 2017-08-16 17:20:17 --> Helper loaded: url_helper
INFO - 2017-08-16 17:20:17 --> Helper loaded: form_helper
INFO - 2017-08-16 17:20:17 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:20:17 --> Form Validation Class Initialized
INFO - 2017-08-16 17:20:17 --> Controller Class Initialized
INFO - 2017-08-16 17:20:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:20:17 --> Model Class Initialized
INFO - 2017-08-16 17:20:17 --> Config Class Initialized
INFO - 2017-08-16 17:20:17 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:20:17 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:20:17 --> Utf8 Class Initialized
INFO - 2017-08-16 17:20:17 --> URI Class Initialized
DEBUG - 2017-08-16 17:20:17 --> No URI present. Default controller set.
INFO - 2017-08-16 17:20:17 --> Router Class Initialized
INFO - 2017-08-16 17:20:17 --> Output Class Initialized
INFO - 2017-08-16 17:20:17 --> Security Class Initialized
DEBUG - 2017-08-16 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:20:17 --> Input Class Initialized
INFO - 2017-08-16 17:20:17 --> Language Class Initialized
INFO - 2017-08-16 17:20:17 --> Loader Class Initialized
INFO - 2017-08-16 17:20:17 --> Helper loaded: url_helper
INFO - 2017-08-16 17:20:17 --> Helper loaded: form_helper
INFO - 2017-08-16 17:20:17 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:20:18 --> Form Validation Class Initialized
INFO - 2017-08-16 17:20:18 --> Controller Class Initialized
INFO - 2017-08-16 17:20:18 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:20:18 --> Model Class Initialized
INFO - 2017-08-16 17:20:18 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:20:18 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:20:18 --> Final output sent to browser
DEBUG - 2017-08-16 17:20:18 --> Total execution time: 0.2852
INFO - 2017-08-16 17:20:22 --> Config Class Initialized
INFO - 2017-08-16 17:20:22 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:20:22 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:20:22 --> Utf8 Class Initialized
INFO - 2017-08-16 17:20:22 --> URI Class Initialized
INFO - 2017-08-16 17:20:22 --> Router Class Initialized
INFO - 2017-08-16 17:20:22 --> Output Class Initialized
INFO - 2017-08-16 17:20:22 --> Security Class Initialized
DEBUG - 2017-08-16 17:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:20:22 --> Input Class Initialized
INFO - 2017-08-16 17:20:22 --> Language Class Initialized
INFO - 2017-08-16 17:20:22 --> Loader Class Initialized
INFO - 2017-08-16 17:20:22 --> Helper loaded: url_helper
INFO - 2017-08-16 17:20:22 --> Helper loaded: form_helper
INFO - 2017-08-16 17:20:22 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:20:22 --> Form Validation Class Initialized
INFO - 2017-08-16 17:20:22 --> Controller Class Initialized
INFO - 2017-08-16 17:20:22 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:20:22 --> Model Class Initialized
INFO - 2017-08-16 17:20:22 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:20:22 --> Final output sent to browser
DEBUG - 2017-08-16 17:20:22 --> Total execution time: 0.2728
INFO - 2017-08-16 17:20:31 --> Config Class Initialized
INFO - 2017-08-16 17:20:31 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:20:31 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:20:31 --> Utf8 Class Initialized
INFO - 2017-08-16 17:20:31 --> URI Class Initialized
INFO - 2017-08-16 17:20:31 --> Router Class Initialized
INFO - 2017-08-16 17:20:31 --> Output Class Initialized
INFO - 2017-08-16 17:20:31 --> Security Class Initialized
DEBUG - 2017-08-16 17:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:20:32 --> Input Class Initialized
INFO - 2017-08-16 17:20:32 --> Language Class Initialized
INFO - 2017-08-16 17:20:32 --> Loader Class Initialized
INFO - 2017-08-16 17:20:32 --> Helper loaded: url_helper
INFO - 2017-08-16 17:20:32 --> Helper loaded: form_helper
INFO - 2017-08-16 17:20:32 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:20:32 --> Form Validation Class Initialized
INFO - 2017-08-16 17:20:32 --> Controller Class Initialized
INFO - 2017-08-16 17:20:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:20:32 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 4
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 51
ERROR - 2017-08-16 17:20:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 51
INFO - 2017-08-16 17:20:32 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:20:32 --> Final output sent to browser
DEBUG - 2017-08-16 17:20:32 --> Total execution time: 0.4263
INFO - 2017-08-16 17:21:36 --> Config Class Initialized
INFO - 2017-08-16 17:21:36 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:21:36 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:21:36 --> Utf8 Class Initialized
INFO - 2017-08-16 17:21:36 --> URI Class Initialized
INFO - 2017-08-16 17:21:36 --> Router Class Initialized
INFO - 2017-08-16 17:21:36 --> Output Class Initialized
INFO - 2017-08-16 17:21:36 --> Security Class Initialized
DEBUG - 2017-08-16 17:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:21:36 --> Input Class Initialized
INFO - 2017-08-16 17:21:36 --> Language Class Initialized
INFO - 2017-08-16 17:21:36 --> Loader Class Initialized
INFO - 2017-08-16 17:21:36 --> Helper loaded: url_helper
INFO - 2017-08-16 17:21:37 --> Helper loaded: form_helper
INFO - 2017-08-16 17:21:37 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:21:37 --> Form Validation Class Initialized
INFO - 2017-08-16 17:21:37 --> Controller Class Initialized
INFO - 2017-08-16 17:21:37 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:21:37 --> Model Class Initialized
INFO - 2017-08-16 17:21:37 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:21:37 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:21:37 --> Final output sent to browser
DEBUG - 2017-08-16 17:21:37 --> Total execution time: 0.2880
INFO - 2017-08-16 17:21:40 --> Config Class Initialized
INFO - 2017-08-16 17:21:40 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:21:40 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:21:40 --> Utf8 Class Initialized
INFO - 2017-08-16 17:21:40 --> URI Class Initialized
INFO - 2017-08-16 17:21:40 --> Router Class Initialized
INFO - 2017-08-16 17:21:41 --> Output Class Initialized
INFO - 2017-08-16 17:21:41 --> Security Class Initialized
DEBUG - 2017-08-16 17:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:21:41 --> Input Class Initialized
INFO - 2017-08-16 17:21:41 --> Language Class Initialized
INFO - 2017-08-16 17:21:41 --> Loader Class Initialized
INFO - 2017-08-16 17:21:41 --> Helper loaded: url_helper
INFO - 2017-08-16 17:21:41 --> Helper loaded: form_helper
INFO - 2017-08-16 17:21:41 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:21:41 --> Form Validation Class Initialized
INFO - 2017-08-16 17:21:41 --> Controller Class Initialized
INFO - 2017-08-16 17:21:41 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:21:41 --> Model Class Initialized
INFO - 2017-08-16 17:21:41 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:21:41 --> Final output sent to browser
DEBUG - 2017-08-16 17:21:41 --> Total execution time: 0.2745
INFO - 2017-08-16 17:21:52 --> Config Class Initialized
INFO - 2017-08-16 17:21:52 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:21:52 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:21:52 --> Utf8 Class Initialized
INFO - 2017-08-16 17:21:52 --> URI Class Initialized
INFO - 2017-08-16 17:21:52 --> Router Class Initialized
INFO - 2017-08-16 17:21:52 --> Output Class Initialized
INFO - 2017-08-16 17:21:52 --> Security Class Initialized
DEBUG - 2017-08-16 17:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:21:52 --> Input Class Initialized
INFO - 2017-08-16 17:21:52 --> Language Class Initialized
INFO - 2017-08-16 17:21:52 --> Loader Class Initialized
INFO - 2017-08-16 17:21:52 --> Helper loaded: url_helper
INFO - 2017-08-16 17:21:52 --> Helper loaded: form_helper
INFO - 2017-08-16 17:21:52 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:21:52 --> Form Validation Class Initialized
INFO - 2017-08-16 17:21:52 --> Controller Class Initialized
INFO - 2017-08-16 17:21:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:21:52 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 4
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 51
ERROR - 2017-08-16 17:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 51
INFO - 2017-08-16 17:21:52 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:21:52 --> Final output sent to browser
DEBUG - 2017-08-16 17:21:52 --> Total execution time: 0.4243
INFO - 2017-08-16 17:22:02 --> Config Class Initialized
INFO - 2017-08-16 17:22:02 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:22:02 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:22:02 --> Utf8 Class Initialized
INFO - 2017-08-16 17:22:02 --> URI Class Initialized
INFO - 2017-08-16 17:22:02 --> Router Class Initialized
INFO - 2017-08-16 17:22:02 --> Output Class Initialized
INFO - 2017-08-16 17:22:02 --> Security Class Initialized
DEBUG - 2017-08-16 17:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:22:02 --> Input Class Initialized
INFO - 2017-08-16 17:22:02 --> Language Class Initialized
INFO - 2017-08-16 17:22:02 --> Loader Class Initialized
INFO - 2017-08-16 17:22:02 --> Helper loaded: url_helper
INFO - 2017-08-16 17:22:02 --> Helper loaded: form_helper
INFO - 2017-08-16 17:22:02 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:22:02 --> Form Validation Class Initialized
INFO - 2017-08-16 17:22:02 --> Controller Class Initialized
ERROR - 2017-08-16 17:22:02 --> Severity: error --> Exception: Too few arguments to function Crud::update(), 0 passed in C:\xampp\htdocs\crud\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\crud\application\controllers\Crud.php 82
INFO - 2017-08-16 17:22:20 --> Config Class Initialized
INFO - 2017-08-16 17:22:20 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:22:20 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:22:20 --> Utf8 Class Initialized
INFO - 2017-08-16 17:22:20 --> URI Class Initialized
INFO - 2017-08-16 17:22:20 --> Router Class Initialized
INFO - 2017-08-16 17:22:20 --> Output Class Initialized
INFO - 2017-08-16 17:22:20 --> Security Class Initialized
DEBUG - 2017-08-16 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:22:20 --> Input Class Initialized
INFO - 2017-08-16 17:22:20 --> Language Class Initialized
INFO - 2017-08-16 17:22:20 --> Loader Class Initialized
INFO - 2017-08-16 17:22:20 --> Helper loaded: url_helper
INFO - 2017-08-16 17:22:20 --> Helper loaded: form_helper
INFO - 2017-08-16 17:22:20 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:22:20 --> Form Validation Class Initialized
INFO - 2017-08-16 17:22:20 --> Controller Class Initialized
ERROR - 2017-08-16 17:22:20 --> Severity: error --> Exception: Too few arguments to function Crud::update(), 0 passed in C:\xampp\htdocs\crud\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\crud\application\controllers\Crud.php 82
INFO - 2017-08-16 17:23:12 --> Config Class Initialized
INFO - 2017-08-16 17:23:12 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:23:12 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:23:12 --> Utf8 Class Initialized
INFO - 2017-08-16 17:23:12 --> URI Class Initialized
INFO - 2017-08-16 17:23:12 --> Router Class Initialized
INFO - 2017-08-16 17:23:12 --> Output Class Initialized
INFO - 2017-08-16 17:23:12 --> Security Class Initialized
DEBUG - 2017-08-16 17:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:23:13 --> Input Class Initialized
INFO - 2017-08-16 17:23:13 --> Language Class Initialized
INFO - 2017-08-16 17:23:13 --> Loader Class Initialized
INFO - 2017-08-16 17:23:13 --> Helper loaded: url_helper
INFO - 2017-08-16 17:23:13 --> Helper loaded: form_helper
INFO - 2017-08-16 17:23:13 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:23:13 --> Form Validation Class Initialized
INFO - 2017-08-16 17:23:13 --> Controller Class Initialized
INFO - 2017-08-16 17:23:13 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:23:13 --> Model Class Initialized
INFO - 2017-08-16 17:23:13 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:23:13 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:23:13 --> Final output sent to browser
DEBUG - 2017-08-16 17:23:13 --> Total execution time: 0.2897
INFO - 2017-08-16 17:23:17 --> Config Class Initialized
INFO - 2017-08-16 17:23:17 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:23:17 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:23:17 --> Utf8 Class Initialized
INFO - 2017-08-16 17:23:17 --> URI Class Initialized
INFO - 2017-08-16 17:23:17 --> Router Class Initialized
INFO - 2017-08-16 17:23:17 --> Output Class Initialized
INFO - 2017-08-16 17:23:17 --> Security Class Initialized
DEBUG - 2017-08-16 17:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:23:17 --> Input Class Initialized
INFO - 2017-08-16 17:23:17 --> Language Class Initialized
INFO - 2017-08-16 17:23:17 --> Loader Class Initialized
INFO - 2017-08-16 17:23:17 --> Helper loaded: url_helper
INFO - 2017-08-16 17:23:17 --> Helper loaded: form_helper
INFO - 2017-08-16 17:23:17 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:23:17 --> Form Validation Class Initialized
INFO - 2017-08-16 17:23:17 --> Controller Class Initialized
INFO - 2017-08-16 17:23:17 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:23:17 --> Model Class Initialized
INFO - 2017-08-16 17:23:17 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:23:17 --> Final output sent to browser
DEBUG - 2017-08-16 17:23:17 --> Total execution time: 0.2828
INFO - 2017-08-16 17:23:22 --> Config Class Initialized
INFO - 2017-08-16 17:23:22 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:23:22 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:23:22 --> Utf8 Class Initialized
INFO - 2017-08-16 17:23:22 --> URI Class Initialized
INFO - 2017-08-16 17:23:22 --> Router Class Initialized
INFO - 2017-08-16 17:23:22 --> Output Class Initialized
INFO - 2017-08-16 17:23:22 --> Security Class Initialized
DEBUG - 2017-08-16 17:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:23:22 --> Input Class Initialized
INFO - 2017-08-16 17:23:22 --> Language Class Initialized
INFO - 2017-08-16 17:23:22 --> Loader Class Initialized
INFO - 2017-08-16 17:23:22 --> Helper loaded: url_helper
INFO - 2017-08-16 17:23:22 --> Helper loaded: form_helper
INFO - 2017-08-16 17:23:22 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:23:22 --> Form Validation Class Initialized
INFO - 2017-08-16 17:23:22 --> Controller Class Initialized
INFO - 2017-08-16 17:23:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-16 17:23:22 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 4
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 51
ERROR - 2017-08-16 17:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 51
INFO - 2017-08-16 17:23:22 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:23:22 --> Final output sent to browser
DEBUG - 2017-08-16 17:23:22 --> Total execution time: 0.4287
INFO - 2017-08-16 17:23:35 --> Config Class Initialized
INFO - 2017-08-16 17:23:35 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:23:35 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:23:35 --> Utf8 Class Initialized
INFO - 2017-08-16 17:23:35 --> URI Class Initialized
INFO - 2017-08-16 17:23:35 --> Router Class Initialized
INFO - 2017-08-16 17:23:35 --> Output Class Initialized
INFO - 2017-08-16 17:23:36 --> Security Class Initialized
DEBUG - 2017-08-16 17:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:23:36 --> Input Class Initialized
INFO - 2017-08-16 17:23:36 --> Language Class Initialized
INFO - 2017-08-16 17:23:36 --> Loader Class Initialized
INFO - 2017-08-16 17:23:36 --> Helper loaded: url_helper
INFO - 2017-08-16 17:23:36 --> Helper loaded: form_helper
INFO - 2017-08-16 17:23:36 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:23:36 --> Form Validation Class Initialized
INFO - 2017-08-16 17:23:36 --> Controller Class Initialized
ERROR - 2017-08-16 17:23:36 --> Severity: error --> Exception: Too few arguments to function Crud::update(), 0 passed in C:\xampp\htdocs\crud\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\crud\application\controllers\Crud.php 82
INFO - 2017-08-16 17:24:23 --> Config Class Initialized
INFO - 2017-08-16 17:24:23 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:24:23 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:24:23 --> Utf8 Class Initialized
INFO - 2017-08-16 17:24:23 --> URI Class Initialized
INFO - 2017-08-16 17:24:23 --> Router Class Initialized
INFO - 2017-08-16 17:24:23 --> Output Class Initialized
INFO - 2017-08-16 17:24:23 --> Security Class Initialized
DEBUG - 2017-08-16 17:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:24:23 --> Input Class Initialized
INFO - 2017-08-16 17:24:23 --> Language Class Initialized
INFO - 2017-08-16 17:24:23 --> Loader Class Initialized
INFO - 2017-08-16 17:24:23 --> Helper loaded: url_helper
INFO - 2017-08-16 17:24:23 --> Helper loaded: form_helper
INFO - 2017-08-16 17:24:23 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:24:23 --> Form Validation Class Initialized
INFO - 2017-08-16 17:24:23 --> Controller Class Initialized
INFO - 2017-08-16 17:24:23 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:24:23 --> Model Class Initialized
INFO - 2017-08-16 17:24:23 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-16 17:24:23 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-16 17:24:23 --> Final output sent to browser
DEBUG - 2017-08-16 17:24:23 --> Total execution time: 0.2898
INFO - 2017-08-16 17:24:27 --> Config Class Initialized
INFO - 2017-08-16 17:24:27 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:24:27 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:24:27 --> Utf8 Class Initialized
INFO - 2017-08-16 17:24:27 --> URI Class Initialized
INFO - 2017-08-16 17:24:27 --> Router Class Initialized
INFO - 2017-08-16 17:24:27 --> Output Class Initialized
INFO - 2017-08-16 17:24:27 --> Security Class Initialized
DEBUG - 2017-08-16 17:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:24:27 --> Input Class Initialized
INFO - 2017-08-16 17:24:27 --> Language Class Initialized
INFO - 2017-08-16 17:24:27 --> Loader Class Initialized
INFO - 2017-08-16 17:24:27 --> Helper loaded: url_helper
INFO - 2017-08-16 17:24:27 --> Helper loaded: form_helper
INFO - 2017-08-16 17:24:27 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:24:27 --> Form Validation Class Initialized
INFO - 2017-08-16 17:24:27 --> Controller Class Initialized
INFO - 2017-08-16 17:24:27 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-16 17:24:27 --> Model Class Initialized
INFO - 2017-08-16 17:24:27 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-16 17:24:27 --> Final output sent to browser
DEBUG - 2017-08-16 17:24:27 --> Total execution time: 0.2809
INFO - 2017-08-16 17:24:35 --> Config Class Initialized
INFO - 2017-08-16 17:24:35 --> Hooks Class Initialized
DEBUG - 2017-08-16 17:24:35 --> UTF-8 Support Enabled
INFO - 2017-08-16 17:24:35 --> Utf8 Class Initialized
INFO - 2017-08-16 17:24:35 --> URI Class Initialized
INFO - 2017-08-16 17:24:35 --> Router Class Initialized
INFO - 2017-08-16 17:24:35 --> Output Class Initialized
INFO - 2017-08-16 17:24:35 --> Security Class Initialized
DEBUG - 2017-08-16 17:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 17:24:35 --> Input Class Initialized
INFO - 2017-08-16 17:24:35 --> Language Class Initialized
INFO - 2017-08-16 17:24:35 --> Loader Class Initialized
INFO - 2017-08-16 17:24:35 --> Helper loaded: url_helper
INFO - 2017-08-16 17:24:35 --> Helper loaded: form_helper
INFO - 2017-08-16 17:24:35 --> Database Driver Class Initialized
DEBUG - 2017-08-16 17:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-16 17:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-16 17:24:35 --> Form Validation Class Initialized
INFO - 2017-08-16 17:24:35 --> Controller Class Initialized
ERROR - 2017-08-16 17:24:35 --> Severity: error --> Exception: Too few arguments to function Crud::update(), 0 passed in C:\xampp\htdocs\crud\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\crud\application\controllers\Crud.php 82
