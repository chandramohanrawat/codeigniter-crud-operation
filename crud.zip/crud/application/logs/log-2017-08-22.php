<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-22 07:39:44 --> Config Class Initialized
INFO - 2017-08-22 07:39:44 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:39:45 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:39:45 --> Utf8 Class Initialized
INFO - 2017-08-22 07:39:45 --> URI Class Initialized
INFO - 2017-08-22 07:39:45 --> Router Class Initialized
INFO - 2017-08-22 07:39:45 --> Output Class Initialized
INFO - 2017-08-22 07:39:45 --> Security Class Initialized
DEBUG - 2017-08-22 07:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:39:45 --> Input Class Initialized
INFO - 2017-08-22 07:39:45 --> Language Class Initialized
INFO - 2017-08-22 07:39:45 --> Loader Class Initialized
INFO - 2017-08-22 07:39:45 --> Helper loaded: url_helper
INFO - 2017-08-22 07:39:46 --> Helper loaded: form_helper
INFO - 2017-08-22 07:39:46 --> Database Driver Class Initialized
DEBUG - 2017-08-22 07:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:39:46 --> Form Validation Class Initialized
INFO - 2017-08-22 07:39:46 --> Controller Class Initialized
INFO - 2017-08-22 07:39:46 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 07:39:46 --> Model Class Initialized
INFO - 2017-08-22 07:39:46 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-22 07:39:46 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-22 07:39:46 --> Final output sent to browser
DEBUG - 2017-08-22 07:39:46 --> Total execution time: 2.2133
INFO - 2017-08-22 07:40:29 --> Config Class Initialized
INFO - 2017-08-22 07:40:29 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:40:29 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:40:29 --> Utf8 Class Initialized
INFO - 2017-08-22 07:40:29 --> URI Class Initialized
INFO - 2017-08-22 07:40:29 --> Router Class Initialized
INFO - 2017-08-22 07:40:29 --> Output Class Initialized
INFO - 2017-08-22 07:40:29 --> Security Class Initialized
DEBUG - 2017-08-22 07:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:40:30 --> Input Class Initialized
INFO - 2017-08-22 07:40:30 --> Language Class Initialized
INFO - 2017-08-22 07:40:30 --> Loader Class Initialized
INFO - 2017-08-22 07:40:30 --> Helper loaded: url_helper
INFO - 2017-08-22 07:40:30 --> Helper loaded: form_helper
INFO - 2017-08-22 07:40:30 --> Database Driver Class Initialized
DEBUG - 2017-08-22 07:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:40:30 --> Form Validation Class Initialized
INFO - 2017-08-22 07:40:30 --> Controller Class Initialized
INFO - 2017-08-22 07:40:30 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 07:40:30 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/create.php
INFO - 2017-08-22 07:40:30 --> Final output sent to browser
DEBUG - 2017-08-22 07:40:30 --> Total execution time: 0.2799
INFO - 2017-08-22 07:40:43 --> Config Class Initialized
INFO - 2017-08-22 07:40:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:40:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:40:43 --> Utf8 Class Initialized
INFO - 2017-08-22 07:40:43 --> URI Class Initialized
INFO - 2017-08-22 07:40:43 --> Router Class Initialized
INFO - 2017-08-22 07:40:43 --> Output Class Initialized
INFO - 2017-08-22 07:40:43 --> Security Class Initialized
DEBUG - 2017-08-22 07:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:40:43 --> Input Class Initialized
INFO - 2017-08-22 07:40:43 --> Language Class Initialized
INFO - 2017-08-22 07:40:43 --> Loader Class Initialized
INFO - 2017-08-22 07:40:43 --> Helper loaded: url_helper
INFO - 2017-08-22 07:40:43 --> Helper loaded: form_helper
INFO - 2017-08-22 07:40:43 --> Database Driver Class Initialized
DEBUG - 2017-08-22 07:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:40:43 --> Form Validation Class Initialized
INFO - 2017-08-22 07:40:44 --> Controller Class Initialized
INFO - 2017-08-22 07:40:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-22 07:40:44 --> Model Class Initialized
INFO - 2017-08-22 07:40:44 --> Config Class Initialized
INFO - 2017-08-22 07:40:44 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:40:44 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:40:44 --> Utf8 Class Initialized
INFO - 2017-08-22 07:40:44 --> URI Class Initialized
DEBUG - 2017-08-22 07:40:44 --> No URI present. Default controller set.
INFO - 2017-08-22 07:40:44 --> Router Class Initialized
INFO - 2017-08-22 07:40:44 --> Output Class Initialized
INFO - 2017-08-22 07:40:44 --> Security Class Initialized
DEBUG - 2017-08-22 07:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:40:44 --> Input Class Initialized
INFO - 2017-08-22 07:40:44 --> Language Class Initialized
INFO - 2017-08-22 07:40:44 --> Loader Class Initialized
INFO - 2017-08-22 07:40:44 --> Helper loaded: url_helper
INFO - 2017-08-22 07:40:44 --> Helper loaded: form_helper
INFO - 2017-08-22 07:40:44 --> Database Driver Class Initialized
DEBUG - 2017-08-22 07:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:40:44 --> Form Validation Class Initialized
INFO - 2017-08-22 07:40:44 --> Controller Class Initialized
INFO - 2017-08-22 07:40:44 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 07:40:44 --> Model Class Initialized
INFO - 2017-08-22 07:40:44 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-22 07:40:44 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-22 07:40:44 --> Final output sent to browser
DEBUG - 2017-08-22 07:40:44 --> Total execution time: 0.2582
INFO - 2017-08-22 07:40:50 --> Config Class Initialized
INFO - 2017-08-22 07:40:50 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:40:50 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:40:50 --> Utf8 Class Initialized
INFO - 2017-08-22 07:40:50 --> URI Class Initialized
INFO - 2017-08-22 07:40:50 --> Router Class Initialized
INFO - 2017-08-22 07:40:50 --> Output Class Initialized
INFO - 2017-08-22 07:40:50 --> Security Class Initialized
DEBUG - 2017-08-22 07:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:40:50 --> Input Class Initialized
INFO - 2017-08-22 07:40:50 --> Language Class Initialized
INFO - 2017-08-22 07:40:50 --> Loader Class Initialized
INFO - 2017-08-22 07:40:50 --> Helper loaded: url_helper
INFO - 2017-08-22 07:40:50 --> Helper loaded: form_helper
INFO - 2017-08-22 07:40:50 --> Database Driver Class Initialized
DEBUG - 2017-08-22 07:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:40:50 --> Form Validation Class Initialized
INFO - 2017-08-22 07:40:50 --> Controller Class Initialized
INFO - 2017-08-22 07:40:50 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 07:40:50 --> Model Class Initialized
INFO - 2017-08-22 07:40:50 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 07:40:50 --> Final output sent to browser
DEBUG - 2017-08-22 07:40:50 --> Total execution time: 0.2837
INFO - 2017-08-22 07:41:54 --> Config Class Initialized
INFO - 2017-08-22 07:41:54 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:41:54 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:41:54 --> Utf8 Class Initialized
INFO - 2017-08-22 07:41:54 --> URI Class Initialized
INFO - 2017-08-22 07:41:54 --> Router Class Initialized
INFO - 2017-08-22 07:41:54 --> Output Class Initialized
INFO - 2017-08-22 07:41:54 --> Security Class Initialized
DEBUG - 2017-08-22 07:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:41:54 --> Input Class Initialized
INFO - 2017-08-22 07:41:54 --> Language Class Initialized
INFO - 2017-08-22 07:41:54 --> Loader Class Initialized
INFO - 2017-08-22 07:41:54 --> Helper loaded: url_helper
INFO - 2017-08-22 07:41:54 --> Helper loaded: form_helper
INFO - 2017-08-22 07:41:54 --> Database Driver Class Initialized
DEBUG - 2017-08-22 07:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:41:54 --> Form Validation Class Initialized
INFO - 2017-08-22 07:41:54 --> Controller Class Initialized
ERROR - 2017-08-22 07:41:54 --> Severity: error --> Exception: Too few arguments to function Crud::update(), 0 passed in C:\xampp\htdocs\crud\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\crud\application\controllers\Crud.php 81
INFO - 2017-08-22 07:45:39 --> Config Class Initialized
INFO - 2017-08-22 07:45:40 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:45:40 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:45:40 --> Utf8 Class Initialized
INFO - 2017-08-22 07:45:40 --> URI Class Initialized
INFO - 2017-08-22 07:45:40 --> Router Class Initialized
INFO - 2017-08-22 07:45:40 --> Output Class Initialized
INFO - 2017-08-22 07:45:40 --> Security Class Initialized
DEBUG - 2017-08-22 07:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:45:40 --> Input Class Initialized
INFO - 2017-08-22 07:45:40 --> Language Class Initialized
INFO - 2017-08-22 07:45:40 --> Loader Class Initialized
INFO - 2017-08-22 07:45:40 --> Helper loaded: url_helper
INFO - 2017-08-22 07:45:40 --> Helper loaded: form_helper
INFO - 2017-08-22 07:45:40 --> Database Driver Class Initialized
DEBUG - 2017-08-22 07:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:45:40 --> Form Validation Class Initialized
INFO - 2017-08-22 07:45:40 --> Controller Class Initialized
ERROR - 2017-08-22 07:45:40 --> Severity: error --> Exception: Too few arguments to function Crud::update(), 0 passed in C:\xampp\htdocs\crud\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\crud\application\controllers\Crud.php 81
INFO - 2017-08-22 07:45:43 --> Config Class Initialized
INFO - 2017-08-22 07:45:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:45:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:45:43 --> Utf8 Class Initialized
INFO - 2017-08-22 07:45:43 --> URI Class Initialized
INFO - 2017-08-22 07:45:43 --> Router Class Initialized
INFO - 2017-08-22 07:45:43 --> Output Class Initialized
INFO - 2017-08-22 07:45:43 --> Security Class Initialized
DEBUG - 2017-08-22 07:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:45:43 --> Input Class Initialized
INFO - 2017-08-22 07:45:43 --> Language Class Initialized
INFO - 2017-08-22 07:45:43 --> Loader Class Initialized
INFO - 2017-08-22 07:45:43 --> Helper loaded: url_helper
INFO - 2017-08-22 07:45:43 --> Helper loaded: form_helper
INFO - 2017-08-22 07:45:43 --> Database Driver Class Initialized
DEBUG - 2017-08-22 07:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:45:43 --> Form Validation Class Initialized
INFO - 2017-08-22 07:45:43 --> Controller Class Initialized
ERROR - 2017-08-22 07:45:43 --> Severity: error --> Exception: Too few arguments to function Crud::update(), 0 passed in C:\xampp\htdocs\crud\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\crud\application\controllers\Crud.php 81
INFO - 2017-08-22 07:59:20 --> Config Class Initialized
INFO - 2017-08-22 07:59:20 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:59:20 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:59:20 --> Utf8 Class Initialized
INFO - 2017-08-22 07:59:20 --> URI Class Initialized
INFO - 2017-08-22 07:59:20 --> Router Class Initialized
INFO - 2017-08-22 07:59:20 --> Output Class Initialized
INFO - 2017-08-22 07:59:20 --> Security Class Initialized
DEBUG - 2017-08-22 07:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:59:20 --> Input Class Initialized
INFO - 2017-08-22 07:59:20 --> Config Class Initialized
INFO - 2017-08-22 07:59:21 --> Language Class Initialized
INFO - 2017-08-22 07:59:21 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:59:21 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:59:21 --> Loader Class Initialized
INFO - 2017-08-22 07:59:21 --> Utf8 Class Initialized
INFO - 2017-08-22 07:59:21 --> Helper loaded: url_helper
INFO - 2017-08-22 07:59:21 --> URI Class Initialized
INFO - 2017-08-22 07:59:21 --> Helper loaded: form_helper
INFO - 2017-08-22 07:59:21 --> Router Class Initialized
INFO - 2017-08-22 07:59:21 --> Database Driver Class Initialized
INFO - 2017-08-22 07:59:21 --> Output Class Initialized
DEBUG - 2017-08-22 07:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:59:21 --> Security Class Initialized
INFO - 2017-08-22 07:59:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-08-22 07:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:59:21 --> Form Validation Class Initialized
INFO - 2017-08-22 07:59:21 --> Input Class Initialized
INFO - 2017-08-22 07:59:21 --> Controller Class Initialized
INFO - 2017-08-22 07:59:21 --> Language Class Initialized
INFO - 2017-08-22 07:59:21 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 07:59:21 --> Loader Class Initialized
INFO - 2017-08-22 07:59:21 --> Model Class Initialized
INFO - 2017-08-22 07:59:21 --> Helper loaded: url_helper
INFO - 2017-08-22 07:59:21 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-22 07:59:21 --> Helper loaded: form_helper
INFO - 2017-08-22 07:59:21 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-22 07:59:21 --> Database Driver Class Initialized
INFO - 2017-08-22 07:59:21 --> Final output sent to browser
DEBUG - 2017-08-22 07:59:21 --> Total execution time: 0.3286
DEBUG - 2017-08-22 07:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:59:21 --> Form Validation Class Initialized
INFO - 2017-08-22 07:59:21 --> Controller Class Initialized
INFO - 2017-08-22 07:59:21 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 07:59:21 --> Model Class Initialized
INFO - 2017-08-22 07:59:21 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-22 07:59:21 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-22 07:59:21 --> Final output sent to browser
DEBUG - 2017-08-22 07:59:21 --> Total execution time: 0.3536
INFO - 2017-08-22 07:59:33 --> Config Class Initialized
INFO - 2017-08-22 07:59:33 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:59:33 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:59:33 --> Utf8 Class Initialized
INFO - 2017-08-22 07:59:33 --> URI Class Initialized
INFO - 2017-08-22 07:59:33 --> Router Class Initialized
INFO - 2017-08-22 07:59:33 --> Output Class Initialized
INFO - 2017-08-22 07:59:33 --> Security Class Initialized
DEBUG - 2017-08-22 07:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:59:33 --> Input Class Initialized
INFO - 2017-08-22 07:59:33 --> Language Class Initialized
INFO - 2017-08-22 07:59:33 --> Loader Class Initialized
INFO - 2017-08-22 07:59:33 --> Helper loaded: url_helper
INFO - 2017-08-22 07:59:33 --> Helper loaded: form_helper
INFO - 2017-08-22 07:59:33 --> Database Driver Class Initialized
DEBUG - 2017-08-22 07:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:59:33 --> Form Validation Class Initialized
INFO - 2017-08-22 07:59:33 --> Controller Class Initialized
INFO - 2017-08-22 07:59:33 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 07:59:33 --> Model Class Initialized
INFO - 2017-08-22 07:59:33 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 07:59:33 --> Final output sent to browser
DEBUG - 2017-08-22 07:59:33 --> Total execution time: 0.2355
INFO - 2017-08-22 07:59:39 --> Config Class Initialized
INFO - 2017-08-22 07:59:39 --> Hooks Class Initialized
DEBUG - 2017-08-22 07:59:39 --> UTF-8 Support Enabled
INFO - 2017-08-22 07:59:39 --> Utf8 Class Initialized
INFO - 2017-08-22 07:59:39 --> URI Class Initialized
INFO - 2017-08-22 07:59:39 --> Router Class Initialized
INFO - 2017-08-22 07:59:39 --> Output Class Initialized
INFO - 2017-08-22 07:59:39 --> Security Class Initialized
DEBUG - 2017-08-22 07:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 07:59:39 --> Input Class Initialized
INFO - 2017-08-22 07:59:39 --> Language Class Initialized
INFO - 2017-08-22 07:59:39 --> Loader Class Initialized
INFO - 2017-08-22 07:59:39 --> Helper loaded: url_helper
INFO - 2017-08-22 07:59:39 --> Helper loaded: form_helper
INFO - 2017-08-22 07:59:39 --> Database Driver Class Initialized
DEBUG - 2017-08-22 07:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 07:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 07:59:39 --> Form Validation Class Initialized
INFO - 2017-08-22 07:59:39 --> Controller Class Initialized
ERROR - 2017-08-22 07:59:39 --> Severity: error --> Exception: Too few arguments to function Crud::update(), 0 passed in C:\xampp\htdocs\crud\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\crud\application\controllers\Crud.php 81
INFO - 2017-08-22 08:00:48 --> Config Class Initialized
INFO - 2017-08-22 08:00:48 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:00:48 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:00:48 --> Utf8 Class Initialized
INFO - 2017-08-22 08:00:48 --> URI Class Initialized
INFO - 2017-08-22 08:00:48 --> Router Class Initialized
INFO - 2017-08-22 08:00:48 --> Output Class Initialized
INFO - 2017-08-22 08:00:48 --> Security Class Initialized
DEBUG - 2017-08-22 08:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:00:48 --> Input Class Initialized
INFO - 2017-08-22 08:00:48 --> Language Class Initialized
INFO - 2017-08-22 08:00:48 --> Loader Class Initialized
INFO - 2017-08-22 08:00:48 --> Helper loaded: url_helper
INFO - 2017-08-22 08:00:48 --> Helper loaded: form_helper
INFO - 2017-08-22 08:00:48 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:00:48 --> Form Validation Class Initialized
INFO - 2017-08-22 08:00:48 --> Controller Class Initialized
INFO - 2017-08-22 08:00:48 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:00:48 --> Model Class Initialized
INFO - 2017-08-22 08:00:48 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:00:48 --> Final output sent to browser
DEBUG - 2017-08-22 08:00:48 --> Total execution time: 0.2453
INFO - 2017-08-22 08:00:51 --> Config Class Initialized
INFO - 2017-08-22 08:00:51 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:00:52 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:00:52 --> Utf8 Class Initialized
INFO - 2017-08-22 08:00:52 --> URI Class Initialized
INFO - 2017-08-22 08:00:52 --> Router Class Initialized
INFO - 2017-08-22 08:00:52 --> Output Class Initialized
INFO - 2017-08-22 08:00:52 --> Security Class Initialized
DEBUG - 2017-08-22 08:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:00:52 --> Input Class Initialized
INFO - 2017-08-22 08:00:52 --> Language Class Initialized
INFO - 2017-08-22 08:00:52 --> Loader Class Initialized
INFO - 2017-08-22 08:00:52 --> Helper loaded: url_helper
INFO - 2017-08-22 08:00:52 --> Helper loaded: form_helper
INFO - 2017-08-22 08:00:52 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:00:52 --> Form Validation Class Initialized
INFO - 2017-08-22 08:00:52 --> Controller Class Initialized
INFO - 2017-08-22 08:00:52 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:00:52 --> Model Class Initialized
INFO - 2017-08-22 08:00:52 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:00:52 --> Final output sent to browser
DEBUG - 2017-08-22 08:00:52 --> Total execution time: 0.2407
INFO - 2017-08-22 08:01:46 --> Config Class Initialized
INFO - 2017-08-22 08:01:46 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:01:46 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:01:46 --> Utf8 Class Initialized
INFO - 2017-08-22 08:01:46 --> URI Class Initialized
INFO - 2017-08-22 08:01:46 --> Router Class Initialized
INFO - 2017-08-22 08:01:46 --> Output Class Initialized
INFO - 2017-08-22 08:01:46 --> Security Class Initialized
DEBUG - 2017-08-22 08:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:01:46 --> Input Class Initialized
INFO - 2017-08-22 08:01:46 --> Language Class Initialized
INFO - 2017-08-22 08:01:46 --> Loader Class Initialized
INFO - 2017-08-22 08:01:46 --> Helper loaded: url_helper
INFO - 2017-08-22 08:01:46 --> Helper loaded: form_helper
INFO - 2017-08-22 08:01:46 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:01:46 --> Form Validation Class Initialized
INFO - 2017-08-22 08:01:46 --> Controller Class Initialized
INFO - 2017-08-22 08:01:46 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:01:46 --> Model Class Initialized
INFO - 2017-08-22 08:01:46 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:01:46 --> Final output sent to browser
DEBUG - 2017-08-22 08:01:46 --> Total execution time: 0.2380
INFO - 2017-08-22 08:02:11 --> Config Class Initialized
INFO - 2017-08-22 08:02:11 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:02:11 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:02:11 --> Utf8 Class Initialized
INFO - 2017-08-22 08:02:11 --> URI Class Initialized
INFO - 2017-08-22 08:02:11 --> Router Class Initialized
INFO - 2017-08-22 08:02:11 --> Output Class Initialized
INFO - 2017-08-22 08:02:11 --> Security Class Initialized
DEBUG - 2017-08-22 08:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:02:11 --> Input Class Initialized
INFO - 2017-08-22 08:02:11 --> Language Class Initialized
INFO - 2017-08-22 08:02:11 --> Loader Class Initialized
INFO - 2017-08-22 08:02:11 --> Helper loaded: url_helper
INFO - 2017-08-22 08:02:11 --> Helper loaded: form_helper
INFO - 2017-08-22 08:02:11 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:02:11 --> Form Validation Class Initialized
INFO - 2017-08-22 08:02:11 --> Controller Class Initialized
ERROR - 2017-08-22 08:02:11 --> Severity: error --> Exception: Too few arguments to function Crud::update(), 0 passed in C:\xampp\htdocs\crud\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\crud\application\controllers\Crud.php 81
INFO - 2017-08-22 08:05:21 --> Config Class Initialized
INFO - 2017-08-22 08:05:22 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:05:22 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:05:22 --> Utf8 Class Initialized
INFO - 2017-08-22 08:05:22 --> URI Class Initialized
INFO - 2017-08-22 08:05:22 --> Router Class Initialized
INFO - 2017-08-22 08:05:22 --> Output Class Initialized
INFO - 2017-08-22 08:05:22 --> Security Class Initialized
DEBUG - 2017-08-22 08:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:05:22 --> Input Class Initialized
INFO - 2017-08-22 08:05:22 --> Language Class Initialized
INFO - 2017-08-22 08:05:22 --> Loader Class Initialized
INFO - 2017-08-22 08:05:22 --> Helper loaded: url_helper
INFO - 2017-08-22 08:05:22 --> Helper loaded: form_helper
INFO - 2017-08-22 08:05:22 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:05:22 --> Form Validation Class Initialized
INFO - 2017-08-22 08:05:22 --> Controller Class Initialized
INFO - 2017-08-22 08:05:22 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:05:22 --> Model Class Initialized
INFO - 2017-08-22 08:05:22 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:05:22 --> Final output sent to browser
DEBUG - 2017-08-22 08:05:22 --> Total execution time: 0.2404
INFO - 2017-08-22 08:05:36 --> Config Class Initialized
INFO - 2017-08-22 08:05:36 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:05:36 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:05:36 --> Utf8 Class Initialized
INFO - 2017-08-22 08:05:36 --> URI Class Initialized
INFO - 2017-08-22 08:05:36 --> Router Class Initialized
INFO - 2017-08-22 08:05:36 --> Output Class Initialized
INFO - 2017-08-22 08:05:36 --> Security Class Initialized
DEBUG - 2017-08-22 08:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:05:36 --> Input Class Initialized
INFO - 2017-08-22 08:05:36 --> Language Class Initialized
INFO - 2017-08-22 08:05:36 --> Loader Class Initialized
INFO - 2017-08-22 08:05:36 --> Helper loaded: url_helper
INFO - 2017-08-22 08:05:36 --> Helper loaded: form_helper
INFO - 2017-08-22 08:05:36 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:05:36 --> Form Validation Class Initialized
INFO - 2017-08-22 08:05:37 --> Controller Class Initialized
INFO - 2017-08-22 08:05:37 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:05:37 --> Model Class Initialized
INFO - 2017-08-22 08:05:37 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:05:37 --> Final output sent to browser
DEBUG - 2017-08-22 08:05:37 --> Total execution time: 0.2313
INFO - 2017-08-22 08:05:38 --> Config Class Initialized
INFO - 2017-08-22 08:05:38 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:05:38 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:05:38 --> Utf8 Class Initialized
INFO - 2017-08-22 08:05:38 --> URI Class Initialized
INFO - 2017-08-22 08:05:38 --> Router Class Initialized
INFO - 2017-08-22 08:05:38 --> Output Class Initialized
INFO - 2017-08-22 08:05:38 --> Security Class Initialized
DEBUG - 2017-08-22 08:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:05:38 --> Input Class Initialized
INFO - 2017-08-22 08:05:38 --> Language Class Initialized
INFO - 2017-08-22 08:05:38 --> Loader Class Initialized
INFO - 2017-08-22 08:05:38 --> Helper loaded: url_helper
INFO - 2017-08-22 08:05:38 --> Helper loaded: form_helper
INFO - 2017-08-22 08:05:38 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:05:38 --> Form Validation Class Initialized
INFO - 2017-08-22 08:05:38 --> Controller Class Initialized
INFO - 2017-08-22 08:05:38 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:05:38 --> Model Class Initialized
INFO - 2017-08-22 08:05:38 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-22 08:05:38 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-22 08:05:38 --> Final output sent to browser
DEBUG - 2017-08-22 08:05:38 --> Total execution time: 0.2838
INFO - 2017-08-22 08:05:43 --> Config Class Initialized
INFO - 2017-08-22 08:05:43 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:05:43 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:05:43 --> Utf8 Class Initialized
INFO - 2017-08-22 08:05:43 --> URI Class Initialized
INFO - 2017-08-22 08:05:43 --> Router Class Initialized
INFO - 2017-08-22 08:05:43 --> Output Class Initialized
INFO - 2017-08-22 08:05:43 --> Security Class Initialized
DEBUG - 2017-08-22 08:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:05:43 --> Input Class Initialized
INFO - 2017-08-22 08:05:43 --> Language Class Initialized
INFO - 2017-08-22 08:05:43 --> Loader Class Initialized
INFO - 2017-08-22 08:05:43 --> Helper loaded: url_helper
INFO - 2017-08-22 08:05:43 --> Helper loaded: form_helper
INFO - 2017-08-22 08:05:43 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:05:43 --> Form Validation Class Initialized
INFO - 2017-08-22 08:05:43 --> Controller Class Initialized
INFO - 2017-08-22 08:05:43 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:05:43 --> Model Class Initialized
INFO - 2017-08-22 08:05:43 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-22 08:05:43 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-22 08:05:43 --> Final output sent to browser
DEBUG - 2017-08-22 08:05:43 --> Total execution time: 0.2387
INFO - 2017-08-22 08:05:49 --> Config Class Initialized
INFO - 2017-08-22 08:05:49 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:05:49 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:05:49 --> Utf8 Class Initialized
INFO - 2017-08-22 08:05:49 --> URI Class Initialized
INFO - 2017-08-22 08:05:49 --> Router Class Initialized
INFO - 2017-08-22 08:05:49 --> Output Class Initialized
INFO - 2017-08-22 08:05:49 --> Security Class Initialized
DEBUG - 2017-08-22 08:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:05:49 --> Input Class Initialized
INFO - 2017-08-22 08:05:49 --> Language Class Initialized
INFO - 2017-08-22 08:05:49 --> Loader Class Initialized
INFO - 2017-08-22 08:05:49 --> Helper loaded: url_helper
INFO - 2017-08-22 08:05:49 --> Helper loaded: form_helper
INFO - 2017-08-22 08:05:49 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:05:49 --> Form Validation Class Initialized
INFO - 2017-08-22 08:05:49 --> Controller Class Initialized
INFO - 2017-08-22 08:05:49 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:05:49 --> Model Class Initialized
INFO - 2017-08-22 08:05:49 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-22 08:05:49 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-22 08:05:49 --> Final output sent to browser
DEBUG - 2017-08-22 08:05:49 --> Total execution time: 0.2428
INFO - 2017-08-22 08:05:51 --> Config Class Initialized
INFO - 2017-08-22 08:05:51 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:05:51 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:05:51 --> Utf8 Class Initialized
INFO - 2017-08-22 08:05:51 --> URI Class Initialized
INFO - 2017-08-22 08:05:51 --> Router Class Initialized
INFO - 2017-08-22 08:05:51 --> Output Class Initialized
INFO - 2017-08-22 08:05:51 --> Security Class Initialized
DEBUG - 2017-08-22 08:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:05:51 --> Input Class Initialized
INFO - 2017-08-22 08:05:51 --> Language Class Initialized
INFO - 2017-08-22 08:05:51 --> Loader Class Initialized
INFO - 2017-08-22 08:05:51 --> Helper loaded: url_helper
INFO - 2017-08-22 08:05:51 --> Helper loaded: form_helper
INFO - 2017-08-22 08:05:51 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:05:51 --> Form Validation Class Initialized
INFO - 2017-08-22 08:05:51 --> Controller Class Initialized
INFO - 2017-08-22 08:05:51 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:05:51 --> Model Class Initialized
INFO - 2017-08-22 08:05:51 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/home.php
INFO - 2017-08-22 08:05:51 --> File loaded: C:\xampp\htdocs\crud\application\views\footer.php
INFO - 2017-08-22 08:05:51 --> Final output sent to browser
DEBUG - 2017-08-22 08:05:51 --> Total execution time: 0.2612
INFO - 2017-08-22 08:05:57 --> Config Class Initialized
INFO - 2017-08-22 08:05:57 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:05:57 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:05:57 --> Utf8 Class Initialized
INFO - 2017-08-22 08:05:57 --> URI Class Initialized
INFO - 2017-08-22 08:05:57 --> Router Class Initialized
INFO - 2017-08-22 08:05:57 --> Output Class Initialized
INFO - 2017-08-22 08:05:57 --> Security Class Initialized
DEBUG - 2017-08-22 08:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:05:57 --> Input Class Initialized
INFO - 2017-08-22 08:05:57 --> Language Class Initialized
INFO - 2017-08-22 08:05:57 --> Loader Class Initialized
INFO - 2017-08-22 08:05:57 --> Helper loaded: url_helper
INFO - 2017-08-22 08:05:57 --> Helper loaded: form_helper
INFO - 2017-08-22 08:05:57 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:05:57 --> Form Validation Class Initialized
INFO - 2017-08-22 08:05:57 --> Controller Class Initialized
INFO - 2017-08-22 08:05:57 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:05:57 --> Model Class Initialized
INFO - 2017-08-22 08:05:57 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:05:57 --> Final output sent to browser
DEBUG - 2017-08-22 08:05:57 --> Total execution time: 0.2371
INFO - 2017-08-22 08:06:17 --> Config Class Initialized
INFO - 2017-08-22 08:06:17 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:06:17 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:06:17 --> Utf8 Class Initialized
INFO - 2017-08-22 08:06:17 --> URI Class Initialized
INFO - 2017-08-22 08:06:17 --> Router Class Initialized
INFO - 2017-08-22 08:06:17 --> Output Class Initialized
INFO - 2017-08-22 08:06:17 --> Security Class Initialized
DEBUG - 2017-08-22 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:06:17 --> Input Class Initialized
INFO - 2017-08-22 08:06:17 --> Language Class Initialized
INFO - 2017-08-22 08:06:17 --> Loader Class Initialized
INFO - 2017-08-22 08:06:17 --> Helper loaded: url_helper
INFO - 2017-08-22 08:06:17 --> Helper loaded: form_helper
INFO - 2017-08-22 08:06:17 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:06:17 --> Form Validation Class Initialized
INFO - 2017-08-22 08:06:17 --> Controller Class Initialized
ERROR - 2017-08-22 08:06:17 --> Severity: error --> Exception: Too few arguments to function Crud::update(), 0 passed in C:\xampp\htdocs\crud\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\crud\application\controllers\Crud.php 81
INFO - 2017-08-22 08:06:50 --> Config Class Initialized
INFO - 2017-08-22 08:06:50 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:06:50 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:06:50 --> Utf8 Class Initialized
INFO - 2017-08-22 08:06:50 --> URI Class Initialized
INFO - 2017-08-22 08:06:50 --> Router Class Initialized
INFO - 2017-08-22 08:06:50 --> Output Class Initialized
INFO - 2017-08-22 08:06:50 --> Security Class Initialized
DEBUG - 2017-08-22 08:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:06:50 --> Input Class Initialized
INFO - 2017-08-22 08:06:50 --> Language Class Initialized
INFO - 2017-08-22 08:06:50 --> Loader Class Initialized
INFO - 2017-08-22 08:06:50 --> Helper loaded: url_helper
INFO - 2017-08-22 08:06:50 --> Helper loaded: form_helper
INFO - 2017-08-22 08:06:50 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:06:50 --> Form Validation Class Initialized
INFO - 2017-08-22 08:06:51 --> Controller Class Initialized
INFO - 2017-08-22 08:06:51 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:06:51 --> Model Class Initialized
INFO - 2017-08-22 08:06:51 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:06:51 --> Final output sent to browser
DEBUG - 2017-08-22 08:06:51 --> Total execution time: 0.2299
INFO - 2017-08-22 08:06:56 --> Config Class Initialized
INFO - 2017-08-22 08:06:56 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:06:56 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:06:56 --> Utf8 Class Initialized
INFO - 2017-08-22 08:06:56 --> URI Class Initialized
INFO - 2017-08-22 08:06:56 --> Router Class Initialized
INFO - 2017-08-22 08:06:56 --> Output Class Initialized
INFO - 2017-08-22 08:06:56 --> Security Class Initialized
DEBUG - 2017-08-22 08:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:06:56 --> Input Class Initialized
INFO - 2017-08-22 08:06:56 --> Language Class Initialized
INFO - 2017-08-22 08:06:56 --> Loader Class Initialized
INFO - 2017-08-22 08:06:56 --> Helper loaded: url_helper
INFO - 2017-08-22 08:06:56 --> Helper loaded: form_helper
INFO - 2017-08-22 08:06:56 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:06:56 --> Form Validation Class Initialized
INFO - 2017-08-22 08:06:56 --> Controller Class Initialized
INFO - 2017-08-22 08:06:56 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:06:57 --> Model Class Initialized
INFO - 2017-08-22 08:06:57 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:06:57 --> Final output sent to browser
DEBUG - 2017-08-22 08:06:57 --> Total execution time: 0.2322
INFO - 2017-08-22 08:06:59 --> Config Class Initialized
INFO - 2017-08-22 08:06:59 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:06:59 --> Utf8 Class Initialized
INFO - 2017-08-22 08:06:59 --> URI Class Initialized
INFO - 2017-08-22 08:06:59 --> Router Class Initialized
INFO - 2017-08-22 08:06:59 --> Output Class Initialized
INFO - 2017-08-22 08:06:59 --> Security Class Initialized
DEBUG - 2017-08-22 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:06:59 --> Input Class Initialized
INFO - 2017-08-22 08:06:59 --> Language Class Initialized
INFO - 2017-08-22 08:06:59 --> Loader Class Initialized
INFO - 2017-08-22 08:06:59 --> Helper loaded: url_helper
INFO - 2017-08-22 08:07:00 --> Helper loaded: form_helper
INFO - 2017-08-22 08:07:00 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:07:00 --> Form Validation Class Initialized
INFO - 2017-08-22 08:07:00 --> Controller Class Initialized
INFO - 2017-08-22 08:07:00 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:07:00 --> Model Class Initialized
INFO - 2017-08-22 08:07:00 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:07:00 --> Final output sent to browser
DEBUG - 2017-08-22 08:07:00 --> Total execution time: 0.2341
INFO - 2017-08-22 08:08:00 --> Config Class Initialized
INFO - 2017-08-22 08:08:00 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:08:00 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:08:00 --> Utf8 Class Initialized
INFO - 2017-08-22 08:08:00 --> URI Class Initialized
INFO - 2017-08-22 08:08:00 --> Router Class Initialized
INFO - 2017-08-22 08:08:00 --> Output Class Initialized
INFO - 2017-08-22 08:08:00 --> Security Class Initialized
DEBUG - 2017-08-22 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:08:00 --> Input Class Initialized
INFO - 2017-08-22 08:08:00 --> Language Class Initialized
INFO - 2017-08-22 08:08:00 --> Loader Class Initialized
INFO - 2017-08-22 08:08:00 --> Helper loaded: url_helper
INFO - 2017-08-22 08:08:00 --> Helper loaded: form_helper
INFO - 2017-08-22 08:08:00 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:08:00 --> Form Validation Class Initialized
INFO - 2017-08-22 08:08:00 --> Controller Class Initialized
INFO - 2017-08-22 08:08:00 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:08:00 --> Model Class Initialized
INFO - 2017-08-22 08:08:48 --> Config Class Initialized
INFO - 2017-08-22 08:08:48 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:08:48 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:08:48 --> Utf8 Class Initialized
INFO - 2017-08-22 08:08:48 --> URI Class Initialized
INFO - 2017-08-22 08:08:48 --> Router Class Initialized
INFO - 2017-08-22 08:08:48 --> Output Class Initialized
INFO - 2017-08-22 08:08:48 --> Security Class Initialized
DEBUG - 2017-08-22 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:08:48 --> Input Class Initialized
INFO - 2017-08-22 08:08:48 --> Language Class Initialized
INFO - 2017-08-22 08:08:48 --> Loader Class Initialized
INFO - 2017-08-22 08:08:48 --> Helper loaded: url_helper
INFO - 2017-08-22 08:08:48 --> Helper loaded: form_helper
INFO - 2017-08-22 08:08:48 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:08:48 --> Form Validation Class Initialized
INFO - 2017-08-22 08:08:48 --> Controller Class Initialized
INFO - 2017-08-22 08:08:48 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:08:48 --> Model Class Initialized
INFO - 2017-08-22 08:08:48 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:08:48 --> Final output sent to browser
DEBUG - 2017-08-22 08:08:48 --> Total execution time: 0.2310
INFO - 2017-08-22 08:09:19 --> Config Class Initialized
INFO - 2017-08-22 08:09:19 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:09:19 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:09:19 --> Utf8 Class Initialized
INFO - 2017-08-22 08:09:19 --> URI Class Initialized
INFO - 2017-08-22 08:09:19 --> Router Class Initialized
INFO - 2017-08-22 08:09:19 --> Output Class Initialized
INFO - 2017-08-22 08:09:19 --> Security Class Initialized
DEBUG - 2017-08-22 08:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:09:19 --> Input Class Initialized
INFO - 2017-08-22 08:09:19 --> Language Class Initialized
INFO - 2017-08-22 08:09:19 --> Loader Class Initialized
INFO - 2017-08-22 08:09:19 --> Helper loaded: url_helper
INFO - 2017-08-22 08:09:19 --> Helper loaded: form_helper
INFO - 2017-08-22 08:09:19 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:09:20 --> Form Validation Class Initialized
INFO - 2017-08-22 08:09:20 --> Controller Class Initialized
INFO - 2017-08-22 08:09:42 --> Config Class Initialized
INFO - 2017-08-22 08:09:42 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:09:42 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:09:42 --> Utf8 Class Initialized
INFO - 2017-08-22 08:09:42 --> URI Class Initialized
INFO - 2017-08-22 08:09:42 --> Router Class Initialized
INFO - 2017-08-22 08:09:42 --> Output Class Initialized
INFO - 2017-08-22 08:09:42 --> Security Class Initialized
DEBUG - 2017-08-22 08:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:09:42 --> Input Class Initialized
INFO - 2017-08-22 08:09:42 --> Language Class Initialized
INFO - 2017-08-22 08:09:42 --> Loader Class Initialized
INFO - 2017-08-22 08:09:42 --> Helper loaded: url_helper
INFO - 2017-08-22 08:09:42 --> Helper loaded: form_helper
INFO - 2017-08-22 08:09:42 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:09:42 --> Form Validation Class Initialized
INFO - 2017-08-22 08:09:42 --> Controller Class Initialized
INFO - 2017-08-22 08:09:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-22 08:09:42 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 2
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 4
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 8
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 18
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 28
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 39
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Undefined variable: record C:\xampp\htdocs\crud\application\views\customer\edit.php 51
ERROR - 2017-08-22 08:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\crud\application\views\customer\edit.php 51
INFO - 2017-08-22 08:09:42 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:09:42 --> Final output sent to browser
DEBUG - 2017-08-22 08:09:42 --> Total execution time: 0.4045
INFO - 2017-08-22 08:09:54 --> Config Class Initialized
INFO - 2017-08-22 08:09:54 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:09:54 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:09:54 --> Utf8 Class Initialized
INFO - 2017-08-22 08:09:54 --> URI Class Initialized
INFO - 2017-08-22 08:09:54 --> Router Class Initialized
INFO - 2017-08-22 08:09:54 --> Output Class Initialized
INFO - 2017-08-22 08:09:54 --> Security Class Initialized
DEBUG - 2017-08-22 08:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:09:54 --> Input Class Initialized
INFO - 2017-08-22 08:09:54 --> Language Class Initialized
INFO - 2017-08-22 08:09:54 --> Loader Class Initialized
INFO - 2017-08-22 08:09:54 --> Helper loaded: url_helper
INFO - 2017-08-22 08:09:54 --> Helper loaded: form_helper
INFO - 2017-08-22 08:09:54 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:09:54 --> Form Validation Class Initialized
INFO - 2017-08-22 08:09:54 --> Controller Class Initialized
INFO - 2017-08-22 08:09:54 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:09:54 --> Model Class Initialized
INFO - 2017-08-22 08:09:54 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:09:54 --> Final output sent to browser
DEBUG - 2017-08-22 08:09:54 --> Total execution time: 0.2426
INFO - 2017-08-22 08:11:10 --> Config Class Initialized
INFO - 2017-08-22 08:11:10 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:11:10 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:11:10 --> Utf8 Class Initialized
INFO - 2017-08-22 08:11:10 --> URI Class Initialized
INFO - 2017-08-22 08:11:10 --> Router Class Initialized
INFO - 2017-08-22 08:11:10 --> Output Class Initialized
INFO - 2017-08-22 08:11:10 --> Security Class Initialized
DEBUG - 2017-08-22 08:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:11:10 --> Input Class Initialized
INFO - 2017-08-22 08:11:10 --> Language Class Initialized
INFO - 2017-08-22 08:11:10 --> Loader Class Initialized
INFO - 2017-08-22 08:11:10 --> Helper loaded: url_helper
INFO - 2017-08-22 08:11:10 --> Helper loaded: form_helper
INFO - 2017-08-22 08:11:10 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:11:10 --> Form Validation Class Initialized
INFO - 2017-08-22 08:11:10 --> Controller Class Initialized
INFO - 2017-08-22 08:11:10 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:11:10 --> Model Class Initialized
INFO - 2017-08-22 08:11:10 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:11:10 --> Final output sent to browser
DEBUG - 2017-08-22 08:11:10 --> Total execution time: 0.2717
INFO - 2017-08-22 08:11:22 --> Config Class Initialized
INFO - 2017-08-22 08:11:22 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:11:22 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:11:22 --> Utf8 Class Initialized
INFO - 2017-08-22 08:11:22 --> URI Class Initialized
INFO - 2017-08-22 08:11:22 --> Router Class Initialized
INFO - 2017-08-22 08:11:22 --> Output Class Initialized
INFO - 2017-08-22 08:11:22 --> Security Class Initialized
DEBUG - 2017-08-22 08:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:11:22 --> Input Class Initialized
INFO - 2017-08-22 08:11:22 --> Language Class Initialized
INFO - 2017-08-22 08:11:22 --> Loader Class Initialized
INFO - 2017-08-22 08:11:22 --> Helper loaded: url_helper
INFO - 2017-08-22 08:11:22 --> Helper loaded: form_helper
INFO - 2017-08-22 08:11:22 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:11:22 --> Form Validation Class Initialized
INFO - 2017-08-22 08:11:22 --> Controller Class Initialized
INFO - 2017-08-22 08:11:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-22 08:11:22 --> Config Class Initialized
INFO - 2017-08-22 08:11:22 --> Hooks Class Initialized
DEBUG - 2017-08-22 08:11:22 --> UTF-8 Support Enabled
INFO - 2017-08-22 08:11:22 --> Utf8 Class Initialized
INFO - 2017-08-22 08:11:22 --> URI Class Initialized
INFO - 2017-08-22 08:11:22 --> Router Class Initialized
INFO - 2017-08-22 08:11:22 --> Output Class Initialized
INFO - 2017-08-22 08:11:22 --> Security Class Initialized
DEBUG - 2017-08-22 08:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-22 08:11:22 --> Input Class Initialized
INFO - 2017-08-22 08:11:22 --> Language Class Initialized
INFO - 2017-08-22 08:11:22 --> Loader Class Initialized
INFO - 2017-08-22 08:11:22 --> Helper loaded: url_helper
INFO - 2017-08-22 08:11:22 --> Helper loaded: form_helper
INFO - 2017-08-22 08:11:22 --> Database Driver Class Initialized
DEBUG - 2017-08-22 08:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-08-22 08:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-22 08:11:22 --> Form Validation Class Initialized
INFO - 2017-08-22 08:11:22 --> Controller Class Initialized
INFO - 2017-08-22 08:11:22 --> File loaded: C:\xampp\htdocs\crud\application\views\header.php
INFO - 2017-08-22 08:11:22 --> Model Class Initialized
INFO - 2017-08-22 08:11:22 --> File loaded: C:\xampp\htdocs\crud\application\views\customer/edit.php
INFO - 2017-08-22 08:11:22 --> Final output sent to browser
DEBUG - 2017-08-22 08:11:22 --> Total execution time: 0.2468
ERROR - 2017-08-22 08:18:43 --> Severity: error --> Exception: Call to undefined function affected_row() C:\xampp\htdocs\crud\application\models\md.php 30
ERROR - 2017-08-22 08:19:30 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::affected_row() C:\xampp\htdocs\crud\application\models\md.php 30
ERROR - 2017-08-22 08:20:45 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::affected_row() C:\xampp\htdocs\crud\application\models\md.php 30
ERROR - 2017-08-22 08:27:57 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::affected_row() C:\xampp\htdocs\crud\application\models\md.php 30
ERROR - 2017-08-22 08:29:24 --> 404 Page Not Found: User_guid/index
ERROR - 2017-08-22 08:29:28 --> 404 Page Not Found: User_guide/index
