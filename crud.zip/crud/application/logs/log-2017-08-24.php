<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-24 18:59:56 --> Severity: error --> Exception: Class Crud already exists and doesn't extend CI_Model C:\xampp\htdocs\crud\system\core\Loader.php 349
ERROR - 2017-08-24 19:01:12 --> Severity: error --> Exception: Class Crud already exists and doesn't extend CI_Model C:\xampp\htdocs\crud\system\core\Loader.php 349
