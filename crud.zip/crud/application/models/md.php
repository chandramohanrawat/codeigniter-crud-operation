<?php
   class Md extends CI_model{

   	public function getPosts(){
   		$query = $this->db->get('customer'); 
   		if($query->num_rows()>0){
   			return $query->result();
   		}
   		
   			

   	}
   	public function saveRecords($data){
         $this->db->insert('customer', $data); 
        return TRUE;

   		
   	}

      public function getsinglePosts($records_id){
         $query = $this->db->get_where('customer', array('id' => $records_id));
         if($query->num_rows()>0){
            return $query->row();
         }
         
      }
      public function update_records($records_id,$data){
         $this->db->where('id', $records_id)
                  ->update('customer', $data);
         return $this->db->affected_rows();
      }
      public function deleteRecords($records_id){
         return $this->db->delete('customer', array('id' => $records_id));

      }
        


   }
 

 ?>