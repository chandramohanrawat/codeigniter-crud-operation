<div class="container">
<h1>Add New  Information</h1>
<?php echo form_open('Crud/save',['class'=>'form-horizontal']); ?>
<div class="form-group">
<label for="inputEmail" class="col-md-2 control-label">CustomerName</label>
  	<div class="col-md-5">
<?php echo form_input(['name'=>'CustomerName','placeholder'=> 'CustomerName','class'=>'form-control']);?>
</div>
<div class="col-md-5">
	<?php echo form_error('CustomerName'); ?>
</div>
</div>
 
 <div class="form-group">
<label for="inputEmail" class="col-md-2 control-label">Phone</label>
  	<div class="col-md-5">
<?php echo form_input(['name'=>'phone','placeholder'=> 'Phone','class'=>'form-control']);?>
</div>
<div class="col-md-5">
	<?php echo form_error('phone'); ?>
</div>
</div>
<div class="form-group">
<label for="inputEmail" class="col-md-2 control-label">Address</label>
  	<div class="col-md-5">
<?php echo form_input(['name'=>'Address','placeholder'=> 'Address','class'=>'form-control']);?>
</div>
<div class="col-md-5">
	<?php echo form_error('Address'); ?>
</div>
</div>

<div class="form-group">
  <label for="inputEmail" class="col-md-2 control-label">city</label>
<div class="col-md-5">
<?php echo form_input(['name'=>'city','placeholder'=> 'city','class'=>'form-control']);?>	

</div>
<div class="col-md-5">
	<?php echo form_error('city')?>

</div>
</div>
<div class="form-group">
  <label for="inputEmail" class="col-md-2 control-label">Country</label>
<div class="col-md-5">
<?php echo form_input(['name'=>'country','placeholder'=> 'Country','class'=>'form-control']);?>	

</div>
<div class="col-md-5">
	<?php echo form_error('city')?>

</div>
</div>

<div class="form-group">
<div class="col-md-10 col-md-offset-3">
<?php echo form_submit(['name'=>'submit','value'=>'submit','class'=>'btn btn-success']);?>
<?php echo form_reset(['name'=>'reset','value'=>'reset','class'=>'btn btn -primary']);?>

</div>
</div>
<?php echo form_close();?>
</div>