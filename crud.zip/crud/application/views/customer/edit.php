<div class="container">
<?php if($msg=$this->session->flashdata('msg')):?>
  <div class="alert alert-dismissible alert-success">
   <?php echo $msg?>

 </div>
 
<?php endif ?>

<?php echo form_open("Crud/update/".$record->id,['class'=>'form-horizontal']); ?>
<h1>update Records</h1>

<div class="form-group">
<label for="inputEmail" class="col-md-2 control-label">CustomerName</label>
  	<div class="col-md-5">
  	<input type='text' name="customername" class="form-control" value="<?=$record->CustomerName?>">
</div>
<div class="col-md-5">
	<?php echo form_error('CustomerName'); ?>
</div>
</div>
 
 <div class="form-group">
<label for="inputEmail" class="col-md-2 control-label">Phone</label>
  	<div class="col-md-5">
  	<input type="text" name="phone" class="form-control" value="<?= $record->phone?>">

</div>
<div class="col-md-5">
	<?php echo form_error('phone'); ?>
</div>
</div>
<div class="form-group">
<label for="inputEmail" class="col-md-2 control-label">Address</label>
  	<div class="col-md-5">
  	<input type="text" name="address" class="form-control" value="<?= $record->Address?>">

</div>
<div class="col-md-5">
	<?php echo form_error('Address'); ?>
</div>
</div>

<div class="form-group">
  <label for="inputEmail" class="col-md-2 control-label">city</label>
<div class="col-md-5">
<input type="text" name="city" class="form-control" value="<?= $record->city?>">
	

</div>
<div class="col-md-5">
	<?php echo form_error('city')?>

</div>
</div>
<div class="form-group">
  <label for="inputEmail" class="col-md-2 control-label">Country</label>
<div class="col-md-5">
<input type="text" name="country" class="form-control" value="<?= $record->country?>">


</div>
<div class="col-md-5">
	<?php echo form_error('city')?>

</div>
</div>

<div class="form-group">
<div class="col-md-10 col-md-offset-3">
<?php echo form_submit(['name'=>'submit','value'=>'submit','class'=>'btn btn-success']);?>
<?php echo form_reset(['name'=>'reset','value'=>'reset','class'=>'btn btn -primary']);?>

</div>
</div>
<?php echo form_close();?>
</div>