<div class="container">
<?php if($msg=$this->session->flashdata('msg')):?>
  <div class="alert alert-dismissible alert-success">
   <?php echo $msg?>

 </div>
 
<?php endif ?>
 
<?php echo anchor('Crud/create', 'Add Post', ['class'=>'btn btn-primary']);?>
<h3> customer information </h3>
<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>CustomerName</th>
      <th>Phone</th>
      <th>Address</th>
      <th>City</th>
      <th>Country</th>
      <th>Operations</th>
    </tr>
  </thead>
  <tbody>
  <?php if(count($records)):?>
  <?php foreach ($records as $record):?>
    <tr>
      <td><?php echo $record->CustomerName;?></td>
      <td><?php echo $record->phone;?></td>
      <td><?php echo $record->Address;?></td>
      <td><?php echo $record->city;?></td>
      <td><?php echo $record->country;?></td>
      <td> 
          <?php echo anchor("Crud/edit/{$record->id}", 'Update', ['class'=>'btn btn-success']);?>

          <?php echo anchor("Crud/delete/{$record->id}", 'Delete', ['class'=>'btn btn-danger']);?>
     </td>
    </tr>
 <?php endforeach;?>
<?php else:?>
<tr>
<td>No Records Found</td>
</tr>
<?php endif;?>
  </tbody>
</table> 
  
</div>
 


